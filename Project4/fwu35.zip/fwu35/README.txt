Project 4: Markov Decision Processes

CS-7641 Machine Learning
Spring 2015
Name: Fujia Wu
GT Account: fwu35

I used the BURLAP java library for this project.
All my code is in the file FourRoom.java.

To run my code:

1) Install BURLAP java library

2) Compiling command:
javac –cp [path to burlap jar] FourRoom.java
where [path-to-burlap-jar] is the path to BURLAP jar library.

3) Running command:
java –cp [path-to-burlap-jar] FourRoom [algorithm] [N]
where[algorithm] can be value, policy, qlearn, corresponding to
value iteration, policy iteration and Q-learning. [N] specifies
 the size of the grid N×N.

4) It is necessary to adjust some parameters inside the raw code
FourRoom.java to repeat all the results I performed in this 
assignment.



 