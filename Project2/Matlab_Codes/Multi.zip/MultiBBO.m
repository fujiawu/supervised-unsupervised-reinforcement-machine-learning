function [NonDomPop] = MultiBBO(ProblemFunction, DisplayFlag, LinearFlag, Blending, MultiMethod, RandSeed, Elitism, PopSize, MaxGen)

% VEGA / NSGA / NPGA / SPEA software for minimizing a continuous multi-objective function,
% except that BBO is used for information sharing, so we call the algorithms VEBBO, NSBBO, NPBBO, and SPBBO

% INPUTS: ProblemFunction = the handle of the function that returns
%                           the handles of the initialization and cost functions.
%         DisplayFlag = true or false, whether or not to display and plot results.
%         RandSeed = random number seed
%         LinearFlag = true to use linear migration models, false to use sinusoidal migration models
%         Blending = migration blend parameter, between 0 and 1; 0 means standard BBO
%         MultiMethod = multi-objective optimization method
%                       1 = VEGA
%                       2 = NSGA
%                       3 = NPGA
%                       4 = SPEA
%         RandSeed = random number seed
%         Elitism = number of elites each generation (doesn't really make sense to use this with SPEA)
%         PopSize = population size
%         MaxGen = generation limit

if ~exist('ProblemFunction', 'var') || isempty(ProblemFunction)
    ProblemFunction = @U01;
end
if ~exist('DisplayFlag', 'var') || isempty(DisplayFlag)
    DisplayFlag = true;
end
if ~exist('LinearFlag', 'var') || isempty(LinearFlag)
    LinearFlag = true;
end
if ~exist('Blending', 'var') || isempty(Blending)
    Blending = 0;
end
if ~exist('MultiMethod', 'var') || isempty(MultiMethod)
    MultiMethod = 1;
end
if ~exist('RandSeed', 'var') || isempty(RandSeed)
    RandSeed = [];
end
if ~exist('Elitism', 'var') || isempty(Elitism)
    if MultiMethod < 4
        Elitism = 2;
    else
        Elitism = 0;
    end
end
if ~exist('PopSize', 'var') || isempty(PopSize)
    PopSize = 100;
end
OPTIONS.popsize = PopSize; % population size
if ~exist('MaxGen', 'var') || isempty(MaxGen)
    MaxGen = 1000;
end
OPTIONS.Maxgen = MaxGen; % generation count limit
OPTIONS.pmutate = 0.01; % mutation probability
OPTIONS.clearDups = true; % replace duplicate individuals with random individuals
OPTIONS.Keep = Elitism; % number of elites
OPTIONS.numVar = 10; % number of dimensions in cost function (30 in the CEC 2009 contest)
OPTIONS.ShiftFlag = 0; % do not randomly shift the solution of the problem
OPTIONS.RotationFlag = 0; % do not randomly rotate the solution of the problem

% Initialization
[OPTIONS, ~, ~, Population, ~, ~] = Init(DisplayFlag, ProblemFunction, OPTIONS, RandSeed);
NumObj = length(Population(1).cost);

% Compute immigration rate and emigration rate for each individual.
% lambda(i) is the immigration rate for habitat i.
% mu(i) is the emigration rate for habitat i.
[lambda, mu] = GetLambdaMu(OPTIONS.popsize, LinearFlag);

% Begin the optimization loop
for GenIndex = 1 : OPTIONS.Maxgen
    if DisplayFlag
        if mod(GenIndex, 100) == 0
            if GenIndex > 100, fprintf('\b\b\b\b\b\b\b\b'), end % print the status to the screen
            fprintf('%5d...', GenIndex)
        end
    end
    if MultiMethod == 1 % VEBBO
        Ranks = GetVERanks(Population);
    elseif MultiMethod == 2 % NSBBO
        Ranks = GetNSRanks(Population);
    elseif MultiMethod == 3 % NPBBO
        Population = GetRecomboPopNPGA(Population);
    elseif MultiMethod == 4 % SPBBO
        if GenIndex == 1
            [Archive, NonDomIndices] = GetNonDominated(Population); % Initialize the SPBBO archive
        else
            [Archive, NonDomIndices] = GetNonDominated([Population, Archive]);
            [Archive] = Prune(Archive, OPTIONS.popsize);
        end
        for i = 1 : length(NonDomIndices) % Replace the archived individuals in the population with random individuals
            if NonDomIndices(i) > length(Population), break, end
            RandomChrom = OPTIONS.MinDomain + (OPTIONS.MaxDomain - OPTIONS.MinDomain) .* rand(1,OPTIONS.numVar);
            Population(NonDomIndices(i)).chrom = RandomChrom;
            Population(NonDomIndices(i)) = OPTIONS.CostFunction(Population(NonDomIndices(i)), OPTIONS);
        end
        [Archive] = ComputeStrengths(Population, Archive); % Compute strengths of individuals in archive
        [Population] = ComputeRawCost(Population, Archive); % Compute raw cost of individuals in population
        [~, ImmigrantRanks] = sort([Population.RawCost], 'ascend'); % Ranks of immigrating population members
        [~, EmigrantRanks] = sort([Archive.RawCost, Population.RawCost], 'ascend'); % Ranks of emigrating population and archive members
        [lambda, ~] = GetLambdaMu(length(Population), LinearFlag); % Immigration rates
        [~, mu] = GetLambdaMu(length(Population)+length(Archive), LinearFlag); % Emigration rates
    end
    if Elitism > 0
        % Save a random selection of nondominated individuals in the temporary ElitePop array.
        NonDomPop = GetNonDominated(Population);
        NumDomPopToAdd = min(OPTIONS.Keep, length(NonDomPop));
        NonDomIndices = randperm(length(NonDomPop));
        ElitePop = NonDomPop(NonDomIndices(1 : NumDomPopToAdd));
    end
    % Begin the BBO migration loop
    TempPop = Population(1, :);
    for i = 1 : length(Population)
        % Probabilistically input new information into habitat i
        for j = 1 : OPTIONS.numVar
            if MultiMethod == 1
                k = randi(NumObj); % Base immigration on a randomly-selected objective function index
                Rank = find(Ranks(k, :) == i, 1); % Rank of the i-th individual with respect to the k-th objective
            elseif MultiMethod == 2
                Rank = find(Ranks == i, 1); % Rank of the i-th individual
            elseif MultiMethod == 3
                Rank = randi(OPTIONS.popsize); % Random population index
            elseif MultiMethod == 4
                Rank = find(ImmigrantRanks == i, 1); % Rank of the i-th individual
            end
            if rand < lambda(Rank)
                % Immigration - Pick a rank from which to obtain a feature (that is, from which to emigrate)
                RandomNum = rand * sum(mu);
                Select = mu(1);
                SelectIndex = 1;
                while (RandomNum > Select) && (SelectIndex < length(mu))
                    SelectIndex = SelectIndex + 1;
                    Select = Select + mu(SelectIndex);
                end
                if MultiMethod == 1
                    k = randi(NumObj); % Base emigration on a randomly-selected objective function index
                    Emigrant = Population(Ranks(k, SelectIndex)); % index of emigrating individual
                elseif MultiMethod == 2
                    Emigrant = Population(Ranks(SelectIndex)); % index of emigrating individual
                elseif MultiMethod == 3
                    Emigrant = Population(randi(OPTIONS.popsize)); % emigrate from random individual in recombination population
                elseif MultiMethod == 4
                    if SelectIndex <= length(Archive)
                        Emigrant = Archive(EmigrantRanks(SelectIndex)); % index of emigrating individual
                    else
                        Emigrant = Population(EmigrantRanks(SelectIndex) - length(Archive)); % index of emigrating individual
                    end
                end
                TempPop(i).chrom(j) = Blending * Population(i).chrom(j) + (1 - Blending) * Emigrant.chrom(j);
            end
        end
    end
    % Mutation
    for i = 1 : length(Population)
        for j = 1 : OPTIONS.numVar
            if rand < OPTIONS.pmutate
                TempPop(i).chrom(j) = OPTIONS.MinDomain(j) + (OPTIONS.MaxDomain(j) - OPTIONS.MinDomain(j)) * rand;
            end
        end
    end
    % Replace the habitats with their new versions
    Population = TempPop;
    % Replace duplicates every 100 generations
    if OPTIONS.clearDups && (mod(GenIndex, 100) == 0)
        Population = ClearDups(Population, OPTIONS);
    end
    Population = OPTIONS.CostFunction(Population, OPTIONS); % Calculate cost
    if Elitism > 0
        Population(end+1 : end+length(ElitePop)) = ElitePop; % Add the previous generation's elites to the population
        % Remove the worst individuals from Population, based on the NSGA ranking method
        Ranks = GetNSRanks(Population);
        k = 0;
        while length(Population) > OPTIONS.popsize
            Population = [Population(1 : Ranks(end-k)-1), Population(Ranks(end-k)+1 : end)];
            k = k + 1;
        end
    end
end
NonDomPop = GetNonDominated(Population);
if DisplayFlag
    fprintf('\n')
    if NumObj == 2
        figure, hold on % Plot the entire population
        for i = 1 : OPTIONS.popsize
            plot(Population(i).cost(1), Population(i).cost(2), '.')
        end
        xlabel('First Objective'), ylabel('Second Objective')
        title('Final Population')
        figure, hold on % Plot the nondominated individuals
        for i = 1 : length(NonDomPop)
            plot(NonDomPop(i).cost(1), NonDomPop(i).cost(2), '.')
        end
        xlabel('First Objective'), ylabel('Second Objective')
        title('Nondominated Individuals')
    elseif NumObj == 3
        figure % Plot the entire population
        for i = 1 : OPTIONS.popsize
            plot3(Population(i).cost(1), Population(i).cost(2), Population(i).cost(3),'.'), hold on
        end
        xlabel('First Objective'), ylabel('Second Objective'), zlabel('Third Objective')
        title('Final Population')
        figure % Plot the nondominated individuals
        for i = 1 : length(NonDomPop)
            plot3(NonDomPop(i).cost(1), NonDomPop(i).cost(2), NonDomPop(i).cost(3), '.'), hold on
        end
        xlabel('First Objective'), ylabel('Second Objective'), zlabel('Third Objective')
        title('Nondominated Individuals')
    end
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [lambda, mu] = GetLambdaMu(N, LinearFlag)
% Compute BBO immigration rate and extinction rate for each species count.
% lambda(i) is the immigration rate for individual i.
% mu(i) is the extinction rate for individual i.
% lambda and mu are sorted from best to worst.
iArray = 1 : N;
if LinearFlag
    mu = (N - iArray) / N; % linear migration curves
else
    mu = (1 + cos(iArray*pi/N)) / 2; % sinusoidal migration curves
end
lambda = 1 - mu;
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Ranks] = GetVERanks(Population)
% Compute ranks according to VEGA method
NumObj = length(Population(1).cost);
Popsize = length(Population);
Cost = zeros(Popsize, 1);
Ranks = zeros(NumObj, Popsize);
for k = 1 : NumObj
    % Return the ranks according to the k-th objective function values
    % Ranks(k, i) = population index of the i-th best individual with respect to the k-th objective function
    for i = 1 : Popsize
        Cost(i) = Population(i).cost(k);
    end
    [~, Ranks(k, :)] = sort(Cost, 'ascend');
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Ranks] = GetNSRanks(Population)
% Compute ranks according to NSGA method (rank 1 = best, rank 2 = second best, etc.)
NumObj = length(Population(1).cost);
TempPop = Population;
NonDomLevel = 1;
PopSize = length(Population);
NonDomLevelArr = zeros(1, PopSize);
NumRanked = 0;
while NumRanked < PopSize
    [~, NonDomIndices] = GetNonDominated(TempPop);
    NonDomLevelArr(NonDomIndices) = NonDomLevel;
    for i = 1 : length(NonDomIndices)
        TempPop(NonDomIndices(i)).cost = inf * ones(1, NumObj);
    end
    NumRanked = NumRanked + length(NonDomIndices);
    NonDomLevel = NonDomLevel + 1;
end
% Ranks(i) = population index of the i-th best individual
[~, Ranks] = sort(NonDomLevelArr, 'ascend');
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [RecomboPop] = GetRecomboPopNPGA(Population)
% Get a population for recombination using the NPGA method
RecomboPop = Population;
NumPop = length(Population);
NumObj = length(Population(1).cost);
rIndex = 0;
while length(RecomboPop) < NumPop
    x = {Population(randi(NumPop)), Population(randi(NumPop))}; % two random individuals
    d = {0, 0}; % number of individuals that dominate x{1} and x{2}
    for sindex = 1 : round(NumPop/10)
        S = Population(randi(NumPop)); % One random individual
        SCost = S.cost;
        for i = 1 : 2 % Check if x{1} and x{2} are dominated by S
            xCost = x{i}.cost;
            if (sum(SCost <= xCost) == NumObj) && (sum(SCost < xCost) > 0)
                d{i} = d{i} + 1;
            end
        end
    end
    % Add the individual x{1} or x{2} that is dominated by fewer S individuals to the recombination population
    rIndex = rIndex + 1;
    if d{1} < d{2}
        RecomboPop(rIndex) = x{1};
    else
        RecomboPop(rIndex) = x{2};
    end
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Archive] = ComputeStrengths(Population, Archive)
% Compute strengths of individuals in Archive using the SPEA method
NumObj = length(Population(1).cost);
for a = 1 : length(Archive)
    aCost = Archive(a).cost;
    Archive(a).strength = 0;
    for p = 1 : length(Population)
        xCost = Population(p).cost;
        if (sum(aCost <= xCost) == NumObj) && (sum(aCost < xCost) > 0)
            Archive(a).strength = Archive(a).strength + 1;
        end
    end
    Archive(a).strength = Archive(a).strength / (length(Population) + 1);
    Archive(a).RawCost = 1 - Archive(a).strength;
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Population] = ComputeRawCost(Population, Archive)
% Compute raw cost of individuals in Population using the SPEA method
NumObj = length(Population(1).cost);
for p = 1 : length(Population)
    xCost = Population(p).cost;
    Population(p).strength = 0; % so that Population and Archive have a consistent structure
    Population(p).RawCost = 1;
    for a = 1 : length(Archive)
        aCost = Archive(a).cost;
        if (sum(aCost <= xCost) == NumObj) && (sum(aCost < xCost) > 0)
            Population(p).RawCost = Population(p).RawCost + Archive(a).strength;
        end
    end
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Archive] = Prune(Archive, PopSize)
% Prune the archive using a clustering method so it contains no more than PopSize individuals
lenArch = length(Archive);
while lenArch > PopSize
    minDistance = inf;
    for i = 1 : lenArch-1
        for j = i+1 : lenArch
            Distance = norm(Archive(i).cost - Archive(j).cost, 2);
            if Distance < minDistance
                minDistance = Distance;
                minIndex = j;
            end
        end
    end
    Archive = [Archive(1 : minIndex-1), Archive(minIndex+1 : end)];
    lenArch = lenArch - 1;
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [NonDomPop, NonDomIndices] = GetNonDominated(Population)
% Find the nondominated individuals in Population and return them in NonDomPop.
% The indices of the nondominated individuals are returned in NonDomIndices.
NumObj = length(Population(1).cost);
NonDomPop = struct(Population);
NonDomIndices = zeros(1, length(NonDomPop));
NonDomCount = 0;
for i = 1 : length(Population)
    iCost = Population(i).cost;
    if find(iCost == inf, 1), continue, end
    DomFlag = false;
    for j = 1 : length(Population)
        if i == j, continue, end
        jCost = Population(j).cost;
        if (sum(jCost <= iCost) == NumObj) && (sum(jCost < iCost) > 0)
            DomFlag = true;
            break
        end
    end
    if ~DomFlag
        NonDomCount = NonDomCount + 1;
        NonDomPop(NonDomCount) = Population(i);
        NonDomIndices(NonDomCount) = i;
    end
end
NonDomPop = NonDomPop(1 : NonDomCount);
NonDomIndices = NonDomIndices(1 : NonDomCount);
return