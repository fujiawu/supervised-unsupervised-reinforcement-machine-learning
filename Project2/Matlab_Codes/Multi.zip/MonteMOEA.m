function [MeanHypervols, MeanNormHypervols] = MonteMOEA

% Monte Carlo evalution of a few multi-objective evolutionary algorithms

nMonte = 10; % number of Monte Carlo runs
% Benchmark functions - test only on the benchmarks without equality constraints
Bench = [ ...
    'U01'; ...
    'U04'; ...
    'U06'; ...
    'U10'];
NumAlgs = 4; % Number of MOEAs to try
nBench = size(Bench, 1);
MeanHypervols = zeros(NumAlgs, nBench);
MeanNormHypervols = zeros(NumAlgs, nBench);
DisplayFlag = false;
LinearFlag = false;
Blending = 0;
RandSeed = fix(sum(100*clock)) + (1 : nMonte) * 1000;
PopSize = 100;
MaxGen = 1000;
for j = 1 : nBench
    for k = 1 : nMonte
        disp(['Monte Carlo simulation ', num2str(k), '/', num2str(nMonte), ', ', ...
            'Benchmark function ', num2str(j), '/', num2str(nBench)]);

        MultiMethod = 1; % VEBBO
        Elitism = 2;
        [NonDomPop] = eval(['MultiBBO(@', Bench(j,:), ', ', num2str(DisplayFlag), ', ', num2str(LinearFlag), ', ', ...
                num2str(Blending), ', ', num2str(MultiMethod), ', ', num2str(RandSeed(k)), ', ', num2str(Elitism), ', ', ...
                num2str(PopSize), ', ', num2str(MaxGen), ');']);
        Population{1} = NonDomPop;

        MultiMethod = 2; % NSBBO
        Elitism = 2;
        [NonDomPop] = eval(['MultiBBO(@', Bench(j,:), ', ', num2str(DisplayFlag), ', ', num2str(LinearFlag), ', ', ...
                num2str(Blending), ', ', num2str(MultiMethod), ', ', num2str(RandSeed(k)), ', ', num2str(Elitism), ', ', ...
                num2str(PopSize), ', ', num2str(MaxGen), ');']);
        Population{2} = NonDomPop;

        MultiMethod = 3; % NPBBO
        Elitism = 2;
        [NonDomPop] = eval(['MultiBBO(@', Bench(j,:), ', ', num2str(DisplayFlag), ', ', num2str(LinearFlag), ', ', ...
                num2str(Blending), ', ', num2str(MultiMethod), ', ', num2str(RandSeed(k)), ', ', num2str(Elitism), ', ', ...
                num2str(PopSize), ', ', num2str(MaxGen), ');']);
        Population{3} = NonDomPop;

        MultiMethod = 4; % SPBBO
        Elitism = 0;
        [NonDomPop] = eval(['MultiBBO(@', Bench(j,:), ', ', num2str(DisplayFlag), ', ', num2str(LinearFlag), ', ', ...
                num2str(Blending), ', ', num2str(MultiMethod), ', ', num2str(RandSeed(k)), ', ', num2str(Elitism), ', ', ...
                num2str(PopSize), ', ', num2str(MaxGen), ');']);
        Population{4} = NonDomPop;
        
        [HyperVolumes, NormHyperVolumes] = GetParetoMetric(Population);
        MeanHypervols(:, j) = ((k - 1) * MeanHypervols(:, j) + HyperVolumes) / k;
        MeanNormHypervols(:, j) = ((k - 1) * MeanNormHypervols(:, j) + NormHyperVolumes) / k;

    end
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [HyperVolumes, NormHyperVolumes] = GetParetoMetric(Populations)
% Compute the reference-point hypervolumes of Populations
% First compute the minimum and maximum of each objective function dimension across all Populations
Pop = Populations{1};
MinCost = +inf * ones(1, length(Pop(1).cost));
MaxCost = -inf * ones(1, length(Pop(1).cost));
NumPops = length(Populations);
for PopIndex = 1 : NumPops
    Pop = Populations{PopIndex};
    PopSize = length(Pop);
    for j = 1 : PopSize
        MinCost = min(MinCost, Pop(j).cost);
        MaxCost = max(MaxCost, Pop(j).cost);
    end
end
% Now use MinCost and MaxCost to define the reference point, which is used to calculate the reference hypervolumes
HypervolRef = MinCost + MaxCost; 
HyperVolumes = zeros(NumPops, 1);
NormHyperVolumes = zeros(NumPops, 1);
for PopIndex = 1 : NumPops
    Pop = Populations{PopIndex};
    PopSize = length(Pop);
    for j = 1 : PopSize
        HyperVolumes(PopIndex) = HyperVolumes(PopIndex) + prod(HypervolRef - Pop(j).cost);
    end
    NormHyperVolumes(PopIndex) = HyperVolumes(PopIndex) / PopSize;
end
return