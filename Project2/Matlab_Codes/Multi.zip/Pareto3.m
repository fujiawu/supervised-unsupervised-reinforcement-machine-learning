function Pareto3

% Plot the Pareto set and front for a simple MOP.

SetPlotOptions
x1 = 0 : 0.02 : 4;
f1 = inline('x1^2');
f2 = inline('cos(x1)^3');

f1Arr = zeros(1, length(x1));
f2Arr = zeros(1, length(x1));
for i = 1 : length(x1)
    f1Arr(i) = f1(x1(i));
    f2Arr(i) = f2(x1(i));
end

Dominated = false(1, length(x1));
for i = 1 : length(x1)
    TestValue1 = f1Arr(i);
    TestValue2 = f2Arr(i);
    for ii = 1 : length(x1)
        if (f1Arr(ii) < TestValue1 && f2Arr(ii) <= TestValue2) || ...
            (f2Arr(ii) < TestValue2 && f1Arr(ii) <= TestValue1)
            Dominated(i) = true;
            break
        end
    end
end

[row] = find(Dominated == false);
f1Pareto = zeros(1, length(row));
f2Pareto = zeros(1, length(row));
for i = 1 : length(row)
    f1Pareto(i) = f1Arr(row(i));
    f2Pareto(i) = f2Arr(row(i));
end
figure, hold on, box on, plot(f1Pareto, f2Pareto, 'b-'), xlabel('f1'), ylabel('f2')

% Use the aggregation method to approximate the Pareto set and Pareto front.
dw = 0.01;
wLen = round(1 / dw) + 1;
f1Pareto = zeros(1, wLen);
f2Pareto = zeros(1, wLen);
x1ParetoAgg = zeros(1, wLen);
k = 0;
for w = 0 : 0.01 : 1
    fAgg = w * f1Arr + (1 - w) * f2Arr;
    [~, ndx] = min(fAgg);
    k = k + 1;
    x1ParetoAgg(k) = x1(ndx);
    f1Pareto(k) = f1Arr(ndx);
    f2Pareto(k) = f2Arr(ndx);
end
plot(f1Pareto, f2Pareto, 'r--'), xlabel('f1'), ylabel('f2')
legend('True Pareto Front', 'Aggregation Approximation')
