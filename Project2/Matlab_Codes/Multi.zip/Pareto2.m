function Pareto2

% Use the aggregation method to find the Pareto set and Pareto front.

w = 0 : 0.01 : 1;
x1 = 2 * (1 - w);
x2 = x1;
f1 = 8 * (1 - w).^2;
f2 = 2 * w.^2;
SetPlotOptions
figure; plot(x1, x2); xlabel('x1'); ylabel('x2'); title('Pareto Set');
figure; plot(f1, f2); xlabel('f1'); ylabel('f2'); title('Pareto Front');