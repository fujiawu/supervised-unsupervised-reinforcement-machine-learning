function Pareto1

% Plot the Pareto set and front for a simple MOP.

SetPlotOptions
x1 = 0 : 0.1 : 2;
x2 = 0 : 0.1 : 2;
figure, subplot(1,2,1), plot(x1, x2), xlabel('x1'), ylabel('x2')

f1 = zeros(length(x1), length(x2));
f2 = zeros(length(x1), length(x2));
f1Pareto = zeros(1, length(x1));
f2Pareto = zeros(1, length(x1));
for i = 1 : length(x1)
    for j = 1 : length(x2)
        f1(i,j) = x1(i)^2 + x2(j)^2;
        f2(i,j) = (x1(i)-2)^2 + (x2(j)-2)^2;
    end
    f1Pareto(i) = f1(i, i);
    f2Pareto(i) = f2(i, i);
end
subplot(1,2,2), plot(f1Pareto, f2Pareto), xlabel('f1'), ylabel('f2')
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Brute force search for the Pareto set and Pareto front
% Dominated = false(length(x1), length(x2));
% for i = 1 : length(x1)
%     for j = 1 : length(x2)
%         TestValue1 = f1(i,j);
%         TestValue2 = f2(i,j);
%         for ii = 1 : length(x1)
%             for jj = 1 : length(x2)
%                 if (f1(ii,jj) < TestValue1 && f2(ii,jj) <= TestValue2) || ...
%                     (f1(ii,jj) <= TestValue1 && f2(ii,jj) < TestValue2)
%                     Dominated(i,j) = true;
%                 end
%             end
%         end
%     end
% end
% 
% x1Pareto = [];
% x2Pareto = [];
% f1Pareto = [];
% f2Pareto = [];
% for i = 1 : length(x1)
%     for j = 1 : length(x2)
%         if ~Dominated(i,j)
%             x1Pareto = [x1Pareto x1(i)];
%             x2Pareto = [x2Pareto x2(j)];
%             f1Pareto = [f1Pareto f1(i,j)];
%             f2Pareto = [f2Pareto f2(i,j)];
%         end
%     end
% end
% 
% figure; plot(x1Pareto, x2Pareto, '.'); xlabel('x1'); ylabel('x2'); title('Pareto Set');
% figure; plot(f1Pareto, f2Pareto, '.'); xlabel('f1'); ylabel('f2'); title('Pareto Front');           