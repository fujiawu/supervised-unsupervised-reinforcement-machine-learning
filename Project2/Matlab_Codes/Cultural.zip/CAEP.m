function [MinCost] = CAEP(ProblemFunction, DisplayFlag, UseBelief, BeliefInertia, OPTIONS)

% Cultural algorithm with evolutionary programming to optimize a general continuous function.

% INPUTS: ProblemFunction = the handle of the function that returns 
%                           the handles of the initialization, cost, and feasibility functions.
%         DisplayFlag = true or false, whether or not to display and plot results.
%         UseBelief = true or false, whether or not to use the belief space
%         BeliefInertia \in [0,1] = inertia of current belief system; 1 means it never changes, and
%           0 means it changes very quickly 
% OUTPUT: MinCost = array of best solution, one element for each generation

if ~exist('ProblemFunction', 'var') || isempty(ProblemFunction)
    ProblemFunction = @Ackley;
end
if ~exist('DisplayFlag', 'var') || isempty(DisplayFlag)
    DisplayFlag = true;
end
if ~exist('UseBelief', 'var') || isempty(UseBelief)
    UseBelief = true;
end
if ~exist('BeliefInertia', 'var') || isempty(BeliefInertia)
    BeliefInertia = 0.5;
end
if ~exist('OPTIONS', 'var') || isempty(OPTIONS)
    OPTIONS.popsize = 50;
    OPTIONS.clearDups = false;
    OPTIONS.numVar = 20;
    OPTIONS.Maxgen = 100;
end
[OPTIONS, MinCost, AvgCost, Population, MinConstrViol, AvgConstrViol] = ...
    Init(DisplayFlag, ProblemFunction, OPTIONS);

% The belief space is comprised of the minimum and maximum values for each dimension
Belief = [OPTIONS.MinDomain.*ones(1, OPTIONS.numVar) ; OPTIONS.MaxDomain.*ones(1, OPTIONS.numVar)];
BeliefArr = zeros(2, OPTIONS.Maxgen+1);
BeliefArr(:, 1) = Belief(:, 1);
gamma = (OPTIONS.MaxDomain - OPTIONS.MinDomain) / 60; % standard mutation variance
DistanceVec = zeros(OPTIONS.popsize, OPTIONS.numVar);
PopPrime = Population; % mutated individuals
Top10PctNdx = round(OPTIONS.popsize / 10); % index of the last individual in the top 10%

% Begin the optimization loop
for GenIndex = 1 : OPTIONS.Maxgen
    if UseBelief
        % Measure how far each individual is from the belief space
        DistanceVec = zeros(size(DistanceVec));
        Distance = zeros(1, OPTIONS.popsize);
        for i = 1 : OPTIONS.popsize
            for k = 1 : OPTIONS.numVar
                if Population(i).chrom(k) < Belief(1, k)
                    DistanceVec(i, k) = Belief(1, k) - Population(i).chrom(k);
                elseif Population(i).chrom(k) > Belief(2, k)
                    DistanceVec(i, k) = Belief(2, k) - Population(i).chrom(k);
                end
                Distance(i) = Distance(i) + abs(DistanceVec(i, k));
            end
        end
    end
    % EP Mutation
    for i = 1 : OPTIONS.popsize
        PopPrime(i).chrom = Population(i).chrom + DistanceVec(i, :) + ...
            sqrt(gamma) .* randn(1, OPTIONS.numVar);
    end
    % Make sure the mutated population does not have duplicates. 
    if OPTIONS.clearDups
        PopPrime = ClearDups(PopPrime, OPTIONS);
    end
    % Calculate cost
    PopPrime = OPTIONS.CostFunction(PopPrime, OPTIONS);
    % Sort from best to worst and save the top half
    [Population] = PopSort([Population PopPrime]);
    Population = Population(1 : OPTIONS.popsize);
    if UseBelief
        % Use the top 10% of the population to update the belief space
        % Old belief has an inertia of 90%, while new behavior has a 10% effect on the new belief
        MinChrom = inf * ones(1, OPTIONS.numVar);
        MaxChrom = -inf * ones(1, OPTIONS.numVar);
        for i = 1 : Top10PctNdx
            MinChrom = min(MinChrom, Population(i).chrom);
            MaxChrom = max(MaxChrom, Population(i).chrom);
        end
        Belief(1, :) = BeliefInertia * Belief(1, :) + (1 - BeliefInertia) * MinChrom;
        Belief(2, :) = BeliefInertia * Belief(2, :) + (1 - BeliefInertia) * MaxChrom;
    end
    [MinCost, AvgCost, MinConstrViol, AvgConstrViol] = ComputeCostAndConstrViol(Population, ...
        MinCost, AvgCost, MinConstrViol, AvgConstrViol, GenIndex, DisplayFlag);
    BeliefArr(:, GenIndex+1) = Belief(:, 1);
end
Conclude(DisplayFlag, OPTIONS, Population, MinCost, AvgCost, MinConstrViol, AvgConstrViol);
if DisplayFlag && UseBelief
    disp('Belief space:')
    for i = 1 : OPTIONS.numVar
        disp([num2str(Belief(1, i)), ', ', num2str(Belief(2, i))])
    end
    % Plot the evolution of the belief space
    figure
    plot(0:GenIndex,BeliefArr(1,:), 0:GenIndex,BeliefArr(2,:))
    xlabel('Generation'), ylabel('Belief Space')
end
return