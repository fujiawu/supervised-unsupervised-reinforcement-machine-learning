function CAEPMonte(ProblemFunction)
if ~exist('ProblemFunction', 'var') || isempty(ProblemFunction)
    ProblemFunction = @Ackley;
end
nMonte = 20;
DisplayFlag = false;
OPTIONS.popsize = 50;
OPTIONS.clearDups = false;
OPTIONS.numVar = 20;
OPTIONS.Maxgen = 100;

nMonte = 2;
OPTIONS.Maxgen = 10;

[OPTIONS] = Init(DisplayFlag, ProblemFunction, OPTIONS);
MinCostNoCA = zeros(OPTIONS.Maxgen+1, nMonte);
MinCostYesCA = zeros(OPTIONS.Maxgen+1, nMonte);
for i = 1 : nMonte
    disp(['Run # ', num2str(i), ' of ', num2str(nMonte)]);
    MinCostNoCA(:, i) = CAEP(ProblemFunction, DisplayFlag, false, [], OPTIONS);
    MinCostYesCA(:, i) = CAEP(ProblemFunction, DisplayFlag, true, [], OPTIONS);
end
MinCostNoCA = mean(MinCostNoCA, 2);
MinCostYesCA = mean(MinCostYesCA, 2);
figure
plot(0 : OPTIONS.Maxgen, MinCostNoCA, 'r--', 0 : OPTIONS.Maxgen, MinCostYesCA, 'b-')
xlabel('Generation')
ylabel('Minimum Cost')
legend('Without Belief Space', 'With Belief Space')