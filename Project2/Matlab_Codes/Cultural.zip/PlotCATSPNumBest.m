function PlotCATSPNumBest
NumBestArray = [
0       0 ;
2500    0 ;
2500	1 ;
2600	2 ;
2600	2 ;
2700	2 ;
2800	3 ;
2900	4 ;
3000	5 ;
3100	5 ;
3200	5 ;
3300	4 ;
3400	5 ;
3500	4 ;
3600	5 ;
3700	6 ;
3800	6 ;
3900	8 ;
4000	11 ;
4100	13 ;
4200	15 ;
4300	17 ;
4400	17 ;
4500	19 ;
4600	20 ;
4700	22 ;
4800	24 ;
4900	24 ;
5000	25 ;
5100	26 ;
5200	27 ;
5300	28 ;
5400	30 ;
5500	32 ;
5600	34 ;
5700	36 ];
SetPlotOptions
plot(NumBestArray(:, 1), NumBestArray(:, 2));
xlabel('Interactions')
ylabel('Number of Optima')