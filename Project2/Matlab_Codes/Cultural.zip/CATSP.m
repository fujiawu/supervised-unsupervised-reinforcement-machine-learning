function [MinCost] = CATSP(DisplayFlag)

% Cultural algorithm to solve the traveling salesman problem (TSP).
% Adapted from "Swarm Intelligence," by James Kennedy and Russell Eberhart, Chapter 6.

% INPUTS: DisplayFlag = true or false, whether or not to display and plot results.
% OUTPUT: MinCost = array of best solution, one element for each interaction

if ~exist('DisplayFlag', 'var') || isempty(DisplayFlag)
    DisplayFlag = true;
end
NumCities = 8; % number of cities in TSP problem
NumRows = 18; % The population is a two-dimensional grid
NumCols = 8;
MaxInteraction = 40 * NumRows * NumCols; % interaction limit
SelectionPressure = 0.9; % probability that a better solution shares information with a worse solution

% Initialize the city coordinates in a unit circle
CityCoords = zeros(NumCities, 2);
CityCoords(1, :) = [1, 0];
DeltaAngle = 2 * pi / NumCities;
for i = 2 : NumCities
    Angle = (i - 1) * DeltaAngle;
    CityCoords(i, :) = [cos(Angle), sin(Angle)];
end

% Initialize the population. Always start at city #1.
Population(NumRows, NumCols).Cities = zeros(1, NumCities);
for i = 1 : NumRows
    for j = 1 : NumCols
        Population(i, j).Cities(1) = 1;
        Population(i, j).Cities(2 : NumCities) = randperm(NumCities-1) + 1;
    end
end
Population = ComputeCost(Population, CityCoords);
BestCost = min([Population.Cost]);

% Begin the optimization loop
MinCost = zeros(MaxInteraction+1, 1);
AvgCost = zeros(MaxInteraction+1, 1);
MinCost(1) = min([Population.Cost]);
AvgCost(1) = mean([Population.Cost]);
OrderArray = zeros(2, NumCities);
for Interaction = 1 : MaxInteraction
    % Pick a random individual
    Row(1) = randi(NumRows);
    Col(1) = randi(NumCols);
    % Pick one of four random neighbors
    RandomNum = rand;
    if RandomNum < 0.25
        Row(2) = Row(1);
        Col(2) = Col(1) + 1;
        if Col(2) > NumCols
            Col(2) = 1;
        end
    elseif RandomNum < 0.50
        Row(2) = Row(1) - 1;
        if Row(2) < 1
            Row(2) = NumRows;
        end
       Col(2) = Col(1);
    elseif RandomNum < 0.75
        Row(2) = Row(1);
        Col(2) = Col(1) - 1;
        if Col(2) < 1
            Col(2) = NumCols;
        end
    else
        Row(2) = Row(1) + 1;
        if Row(2) > NumRows
            Row(2) = 1;
        end
       Col(2) = Col(1);
    end
    % Check how similar the neighbors are
    % OrderArray(j, i) is the city index that follows city #i in the j-th chosen individual
    for k = 1 : 2
        for i = 1 : NumCities
            Index = find(Population(Row(k), Col(k)).Cities == i);
            if Index == NumCities
                OrderArray(k, i) = 0; % City #i is at the end of the tour
            else
                OrderArray(k, i) = Population(Row(k), Col(k)).Cities(Index + 1);
            end
        end
    end
    OrderDiff = OrderArray(1, :) - OrderArray(2, :);
    Similarity = length(find(OrderDiff == 0));
    % We have a high probability of sharing information between similar neighbors
    Prob = (Similarity + 1) / (NumCities + 1);
    if rand < Prob
        % Which individual is better and which is worse?
        if Population(Row(1), Col(1)).Cost < Population(Row(2), Col(2)).Cost
            BetterIndex = 1;
            WorseIndex = 2;
        else
            WorseIndex = 1;
            BetterIndex = 2;
        end
        % We have a greater chance of sharing information from a good solution to a bad solution
        if rand < SelectionPressure
            FromSoln = BetterIndex;
            ToSoln = WorseIndex;
        else
            FromSoln = WorseIndex;
            ToSoln = BetterIndex;
        end
        % Cycle crossover
        Index = randi(NumCities - 1) + 1;
        City = Population(Row(FromSoln), Col(FromSoln)).Cities(Index);
        FirstCity = City;
        while true
            NextCity = Population(Row(ToSoln), Col(ToSoln)).Cities(Index);
            Population(Row(ToSoln), Col(ToSoln)).Cities(Index) = City;
            if (NextCity == FirstCity), break, end
            City = NextCity;
            Index = find(Population(Row(FromSoln), Col(FromSoln)).Cities == City);
        end
        % Calculate cost
        Population(Row(ToSoln), Col(ToSoln)) = ComputeCost(Population(Row(ToSoln), Col(ToSoln)), CityCoords);
        BestCost = min(Population(Row(ToSoln), Col(ToSoln)).Cost, BestCost);
    end
    % Display info to screen
    Indices = find([Population.Cost] == BestCost);
    NumBest = length(Indices);
    MinCost(Interaction+1) = BestCost;
    AvgCost(Interaction+1) = mean([Population.Cost]);
    if DisplayFlag && (mod(Interaction, 100) == 0)
        disp(['Best and mean of Interaction # ', num2str(Interaction), ' = ',...
            num2str(BestCost), ', ', num2str(AvgCost(Interaction+1)), ', # optima = ', num2str(NumBest)]);
    end
end
if DisplayFlag
    % Plot convergence progress
    SetPlotOptions
    plot(0:Interaction,AvgCost,'b-', 0:Interaction,MinCost,'r--')
    xlabel('Interactions'), ylabel('Cost')
    legend('Average', 'Minimum')
    % Display solutions
    warning off MATLAB:sprintf:InputForPercentSIsNotOfClassChar
    for i = 1 : NumRows
        Ind = '';
        for j = 1 : NumCols
            for k = 1 : NumCities
                Ind = [Ind, sprintf('%s', 64+Population(i, j).Cities(k))]; %#ok<AGROW> % 1 = 'A', 2 = 'B', etc.
            end
            Ind = [Ind, ' ']; %#ok<AGROW>
        end
        disp(Ind)
    end
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Population] = ComputeCost(Population, CityCoords)
% Compute the distance of each tour in the Population array
for i = 1 : size(Population, 1)
    for j = 1 : size(Population, 2)
        Population(i, j).Cost = 0;
        for k = 1 : length(Population(i, j).Cities)-1
            StartCity = Population(i, j).Cities(k);
            NextCity = Population(i, j).Cities(k + 1);
            Deltax = CityCoords(StartCity, 1) - CityCoords(NextCity, 1);
            Deltay = CityCoords(StartCity, 2) - CityCoords(NextCity, 2);
            Population(i, j).Cost = Population(i, j).Cost + sqrt(Deltax^2 + Deltay^2);
        end
    end
end
return
            