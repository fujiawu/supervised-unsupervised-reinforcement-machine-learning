function CAEPMutate1
SetPlotOptions
x = -3 : .1 : 3;
f = exp(-x.^2) / sqrt(2*pi);
figure
% Make the figure twice as wide as normal
FigSize = get(gcf, 'Position');
set(gcf, 'Position', [1, FigSize(2), 2*FigSize(3), FigSize(4)])
subplot(1,2,1)
plot(x, f)
axis([-3 3 0 0.4])
set(gca, 'XTick', -3:1:3)
set(gca, 'XTickLabel', {'', 'B(k,min)', '', 'x(k)', '', 'B(k,max)', ''})
set(gca, 'YTick', [0,4])
set(gca, 'YTickLabel', {'', ''})
ylabel('PDF of x''(k)')
subplot(1,2,2)
plot(x, f)
axis([-3 3 0 0.4])
set(gca, 'XTick', -3:1:3)
set(gca, 'XTickLabel', {'', 'x(k)', '', 'B(k,min)', '', 'B(k,max)', ''})
set(gca, 'YTick', [0,4])
set(gca, 'YTickLabel', {'', ''})
