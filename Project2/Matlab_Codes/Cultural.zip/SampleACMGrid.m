function SampleACMGrid
NumRows = 6;
NumCols = 6;
ProblemDim = 8;
for i = 1 : NumRows
    Ind = '';
    for j = 1 : NumCols
        for k = 1 : ProblemDim
            Ind = [Ind, sprintf('%s', 64+randi(ProblemDim))]; %#ok<AGROW> % 1 = 'A', 2 = 'B', etc.
        end
        Ind = [Ind, ' ']; %#ok<AGROW>
    end
    disp(Ind)
end