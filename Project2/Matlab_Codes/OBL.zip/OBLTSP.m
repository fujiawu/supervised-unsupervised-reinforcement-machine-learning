function [MinDistance] = OBLTSP(Filename, DisplayFlag, JumpRate, JumpRatio, RandSeed)

% Oppositional biogeography-based optimization for solving a traveling salesman problem.
% The basic information-sharing mechanism is inver-over crossover.

% INPUTS: Filename is the name of the file that has the TSP data (no extension; .TSP assumed)
%             Assumed format of file is from http://comopt.ifi.uni-heidelberg.de/software/TSPLIB95/
%         DisplayFlag says whether or not to display information during iterations and plot results
%         JumpRate is the oppositional jumping rate
%         JumpRatio is the proportion of individuals for which to generate opposites
%         RandSeed is the seed for the random number generator
% OUTPUT: MinDistance = array of minimum distances obtained at each generation

if ~exist('Filename', 'var') || isempty(Filename)
    Filename = 'ulysses16';
end
if ~exist('DisplayFlag', 'var') || isempty(DisplayFlag)
    DisplayFlag = true;
end
if ~exist('JumpRate', 'var') || isempty(JumpRate)
    JumpRate = 0.3;
end
if ~exist('JumpRatio', 'var') || isempty(JumpRatio)
    JumpRatio = 0.3;
end
if ~exist('RandSeed', 'var') || isempty(RandSeed)
    RandSeed = round(sum(100*clock));
end
rng(RandSeed);
if DisplayFlag
    disp('Initializing ...')
end
MaxFnEval = 10000; % function evaluation limit
Keep = 0; % elitism parameter: how many of the best individuals to keep from one generation to the next
pm = 0; % mutation rate
% Read the input file and fill up the Coordinates array with the coordinates of each city
[Coord, EdgeWeightType] = GetCoordinates(Filename);
if isequal(EdgeWeightType, 'EUC_2D')
elseif isequal(EdgeWeightType, 'GEO')
    Coord = GetLongLat(Coord);
else
    disp('Edge Weight Type not recognized')
    return
end
DistanceArray = CreateDistanceArray(Coord, EdgeWeightType);
% Initialize the population and calculate the distance of each tour
NumCities = size(Coord, 1);
PopSize = 10 * NumCities;
JumpNum = round(JumpRatio * PopSize);
Population = struct('Tour', cell([1 PopSize]), 'Distance', cell([1 PopSize]));
for i = 1 : PopSize
    Population(i).Tour = randperm(NumCities);
    % Don't use the round trip option, because I don't want to figure out how inver-over crossover works
    % in that situation.
    %Population(i).Tour(end+1) = Population(i).Tour(1); % Make the tour a round trip
    Population(i).Distance = CalcDistance(Population(i).Tour, DistanceArray);
end
[Population] = PopSort(Population);
FnEval = PopSize;
FnEvalArr = zeros(1, round(MaxFnEval/PopSize));
MinDistance = zeros(1, round(MaxFnEval/PopSize));
AvgDistance = zeros(1, round(MaxFnEval/PopSize));
FnEvalArr(1) = FnEval;
MinDistance(1) = Population(1).Distance;
AvgDistance(1) = mean([Population.Distance]);
if DisplayFlag
    disp(['Random seed = ', num2str(RandSeed)]);
    disp(['The best and mean of Generation # 0 are ', ...
        num2str(MinDistance(1)), ' and ', num2str(AvgDistance(1))]);
    % Plot the initial best tour
    SetPlotOptions
    PlotTour(Coord, Population(1).Tour)
end
% Compute immigration rate and emigration rate for each individual.
% lambda(i) is the immigration rate for habitat i.
% mu(i) is the emigration rate for habitat i.
lambda = (1 : PopSize) / PopSize;
mu = 1 - lambda;
% Begin the optimization loop
iGen = 1;
while FnEval < MaxFnEval
    ElitePop = Population(1 : Keep);
    NewPop = Population;
    for k = 1 : PopSize
        if rand < lambda(k)
            % Immigate to the k-th individual. Pick the emigrating individual.
            RandomNum = rand * sum(mu);
            Select = mu(1);
            Emigrant = 1;
            while (RandomNum > Select) && (Emigrant < PopSize)
                Emigrant = Emigrant + 1;
                Select = Select + mu(Emigrant);
            end
            % Inver-over migration
            NewPop(k) = Population(k);
            MigrationCity = randi(NumCities);
            indexStartIm = find(NewPop(k).Tour == MigrationCity, 1);
            index = find(Population(Emigrant).Tour == MigrationCity, 1);
            if index < NumCities
                NextCityEm = Population(Emigrant).Tour(index + 1);
                indexEndIm = find(NewPop(k).Tour == NextCityEm, 1);
            else
                indexEndIm = NumCities;
            end
            if indexEndIm > indexStartIm
                NewPop(k).Tour(indexStartIm+1 : indexEndIm) = fliplr(NewPop(k).Tour(indexStartIm+1 : indexEndIm));
            else
                NewPop(k).Tour(indexEndIm : indexStartIm-1) = fliplr(NewPop(k).Tour(indexEndIm : indexStartIm-1));
            end
            if rand < pm
                % mutation
                index1 = randi(NumCities);
                index2 = randi(NumCities);
                while index1 == index2
                    index2 = randi(NumCities);
                end
                if index2 > index1
                    NewPop(k).Tour(index1 : index2) = fliplr(NewPop(k).Tour(index1 : index2));
                else
                    NewPop(k).Tour(index2 : index1) = fliplr(NewPop(k).Tour(index2 : index1));
                end
            end
            NewPop(k).Distance = CalcDistance(NewPop(k).Tour, DistanceArray);
            FnEval = FnEval + 1;
        end
    end
    if (rand < JumpRate) && (JumpNum > 0)
        WorstPop = PopSort(NewPop(PopSize-JumpNum+1 : PopSize));
        OppPop = Opposite(WorstPop);
        for k = 1 : length(OppPop)
            OppPop(k).Distance = CalcDistance(OppPop(k).Tour, DistanceArray);
        end
        FnEval = FnEval + length(OppPop);
        Population = PopSort([NewPop, OppPop, ElitePop]);
    else
        Population = PopSort([NewPop, ElitePop]);
    end
    Population = Population(1 : PopSize);
    iGen = iGen + 1;
    if FnEval > MaxFnEval, break, end
    FnEvalArr(iGen) = FnEval;
    MinDistance(iGen) = Population(1).Distance;
    AvgDistance(iGen) = mean([Population.Distance]);
    if DisplayFlag
        disp(['The best and mean of Generation # ', num2str(iGen), ' are ', ...
            num2str(MinDistance(iGen)), ' and ', num2str(AvgDistance(iGen))]);
    end
end
index = find(FnEvalArr == 0, 1);
if index > 1
    FnEvalArr = FnEvalArr(1, index-1);
    MinDistance = MinDistance(1, index-1);
    AvgDistance = AvgDistance(1, index-1);
end
if DisplayFlag
    Conclude(Population, FnEvalArr, MinDistance, AvgDistance, Coord);
    PlotBestTour(Filename, Coord, DistanceArray);
    NumDups = CountDups(Population);
    display([num2str(NumDups/PopSize), '% duplicate tours in population'])
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Coord, EdgeWeightType] = GetCoordinates(Filename)
fid = fopen([Filename, '.tsp']);
FileData = textscan(fid, '%s');
fclose(fid);
FileData = FileData{1, 1};
for i = 1 : length(FileData)
    if isequal(FileData{i}, 'DIMENSION:'), break, end
end
dim = str2double(FileData{i+1});
for k = i+2 : length(FileData)
    if isequal(FileData{k}, 'EDGE_WEIGHT_TYPE:'), break, end
end
EdgeWeightType = FileData{k+1};
Coord = zeros(dim, 2);
for j = k+2 : length(FileData)
    if isequal(FileData{j}, 'NODE_COORD_SECTION'), break, end
end
for i = 1 : dim
    Coord(i, 1) = str2double(FileData{j+2});
    Coord(i, 2) = str2double(FileData{j+3});
    j = j + 3;
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [LongLat] = GetLongLat(Coord)
Deg = fix(Coord);
Min = Coord - Deg;
LongLat = pi * (Deg + 5 * Min / 3) / 180;
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Distance] = CalcDistance(Tour, DistanceArray)
Distance = 0;
for i = 1 : length(Tour)-1
    Distance = Distance + DistanceArray(Tour(i), Tour(i+1));
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Population, indices] = PopSort(Population)
% Sort the population members from best to worst
popsize = length(Population);
[Distances, indices] = sort([Population.Distance], 'ascend');
Tours = zeros(popsize, length(Population(1).Tour));
for i = 1 : popsize
    Tours(i, :) = Population(indices(i)).Tour;
end
for i = 1 : popsize
    Population(i).Tour = Tours(i, :);
    Population(i).Distance = Distances(i);
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [DistanceArray] = CreateDistanceArray(Coord, EdgeWeightType)
dim = size(Coord, 1);
DistanceArray = zeros(dim, dim);
RRR = 6378.388;
for i = 1 : dim
    for j = 1 : dim
        if isequal(EdgeWeightType, 'EUC_2D')
            DistanceArray(i, j) = round( norm(Coord(i,:) - Coord(j,:)) );
        elseif isequal(EdgeWeightType, 'GEO')
            q1 = cos( Coord(i,2) - Coord(j,2) );
            q2 = cos( Coord(i,1) - Coord(j,1) );
            q3 = cos( Coord(i,1) + Coord(j,1) );
            DistanceArray(i, j) = floor( RRR * acos( 0.5*((1+q1)*q2 - (1-q1)*q3) ) + 1 );
        end
    end
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Conclude(Population, FnEvalArr, MinDistance, AvgDistance, Coord)
% Display the best solution
Tour = Population(1).Tour;
disp(['Best tour found: ', num2str(Tour)]); 
% Plot some results
MinDistance = MinDistance(1 : length(FnEvalArr));
AvgDistance = AvgDistance(1 : length(FnEvalArr));
figure
plot(FnEvalArr, AvgDistance, 'r--', FnEvalArr, MinDistance, 'b-')
legend('Average Distance', 'Shortest Distance')
xlabel('Function Evaluations')
ylabel('Distance')
PlotTour(Coord, Population(1).Tour)
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function PlotTour(Coord, Tour)
figure, hold on
for i = 1 : length(Tour)-1
    plot(Coord(Tour(i),1), Coord(Tour(i),2), 'r*');
    plot([Coord(Tour(i),1) Coord(Tour(i+1),1)], [Coord(Tour(i),2), Coord(Tour(i+1),2)], 'b-');
end
plot(Coord(Tour(end),1), Coord(Tour(end),2), 'r*'); % necessary only if not plotting round trip
xlabel('Longitude')
ylabel('Latitude')
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function PlotBestTour(Filename, Coord, DistanceArray)
fid = fopen([Filename, '.opt.tour']);
FileData = textscan(fid, '%s');
fclose(fid);
FileData = FileData{1, 1};
for i = 1 : length(FileData)
    if isequal(FileData{i}, 'TOUR_SECTION'), break, end
end
NumCities = str2double(FileData{i-1});
Tour = zeros(1, NumCities+1);
j = i + 1;
for i = 1 : NumCities
    Tour(i) = str2double(FileData{j});
    j = j + 1;
end
Tour(end) = Tour(1);
Distance = CalcDistance(Tour, DistanceArray);
disp(['Minimum distance = ', num2str(Distance)]);
PlotTour(Coord, Tour)
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [NumDups] = CountDups(Population)
NumUnique = 0;
DupIndices = [];
for i = 1 : length(Population)
    if find(DupIndices == i), continue, end
    Tour1 = Population(i).Tour;
    UniqueFlag = 1;
    for j = i+1 : length(Population)
        Tour2 = Population(j).Tour;
        if isequal(Tour1, Tour2)
            DupIndices = [DupIndices j]; %#ok<AGROW>
            UniqueFlag = 0;
            break
        end
    end
    NumUnique = NumUnique + UniqueFlag;
end
NumDups = length(Population) - NumUnique;
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [OppPop] = Opposite(Population)
% Create the opposite population
m = zeros(1, length(Population(1).Tour));
for k = 1 : length(m)
    if mod(k, 2) == 1
        m(k) = (k + 1) / 2;
    else
        m(k) = length(m) + 1 - k / 2;
    end
end
OppPop = Population;
for k = 1 : length(Population)
    OppPop(k).Tour = Population(k).Tour(m);
end
return