function [MinCost] = OBBO(ProblemFunction, DisplayFlag, RandSeed, OppositionType, JumpRate, ...
    FnEvalMax, OppRate, ShiftFlag, Dimension)

% Oppositional biogeography-based optimization (OBBO) software for minimizing a continuous function

% INPUTS: ProblemFunction = the handle of the function that returns 
%                           the handles of the initialization and cost functions.
%         DisplayFlag = true or false, whether or not to display and plot results.
%         RandSeed = random number seed
%         OppositionType = 0 (no opposition)
%                          1 (opposition)
%                          2 (quasi opposition)
%                          3 (super opposition)
%                          4 (quasi reflected opposition)
%         JumpRate = probability each generation of creating an opposite population
%         FnEvalMax = maximum number of function evaluations
%         OppRate = the fraction of the population for which we generate opposites
%         ShiftFlag = whether or not to shift the solution to a random point in the search space
%                     0 (no shift)
%                     1 (shift using a uniform random number)
%                     2 (shift using a Gaussian random number)
%         Dimension = problem dimension
% OUTPUT: MinCost = array of best solution
 
if ~exist('ProblemFunction', 'var') || isempty(ProblemFunction)
    ProblemFunction = @Ackley;
end
if ~exist('DisplayFlag', 'var') || isempty(DisplayFlag)
    DisplayFlag = true;
end
if ~exist('RandSeed', 'var') || isempty(RandSeed)
    RandSeed = fix(sum(100*clock));
end
if ~exist('OppositionType', 'var') || isempty(OppositionType)
    OppositionType = 0;
end
if ~exist('JumpRate', 'var') || isempty(JumpRate)
    JumpRate = 0.3;
end
if ~exist('FnEvalMax', 'var') || isempty(FnEvalMax)
    FnEvalMax = 2500;
end
if ~exist('OppRate', 'var') || isempty(OppRate)
    OppRate = 1;
end
if ~exist('ShiftFlag', 'var') || isempty(ShiftFlag)
    ShiftFlag = 0;
end
OPTIONS.ShiftFlag = ShiftFlag;
if ~exist('Dimension', 'var') || isempty(Dimension)
    Dimension = 20;
end
OPTIONS.numVar = Dimension;

% Initialization
[OPTIONS, MinCost, AvgCost, Population, MinConstrViol, AvgConstrViol] = ...
    Init(DisplayFlag, ProblemFunction, OPTIONS, RandSeed);
FnEvals = OPTIONS.popsize; % function evaluations
FnEvalArr = FnEvals;
NumOpps = round(OppRate * OPTIONS.popsize); % number of individuals for which to generate opposites

% Compute immigration rate and emigration rate for each individual.
% lambda(i) is the immigration rate for habitat i.
% mu(i) is the emigration rate for habitat i.
lambda = (1 : OPTIONS.popsize) / OPTIONS.popsize;
mu = 1 - lambda;

% Begin the optimization loop
GenIndex = 1;
while FnEvals < FnEvalMax
    % Save the best habitats in a temporary array.
    ElitePop = Population(1 : OPTIONS.Keep);
    TempPop = Population;
    for k = 1 : length(Population)
        % Probabilistically migrate new information into habitat i
        for j = 1 : OPTIONS.numVar
            if rand < lambda(k)
                % Pick a habitat from which to obtain a feature
                RandomNum = rand * sum(mu);
                Select = mu(1);
                SelectIndex = 1;
                while (RandomNum > Select) && (SelectIndex < OPTIONS.popsize)
                    SelectIndex = SelectIndex + 1;
                    Select = Select + mu(SelectIndex);
                end
                TempPop(k).chrom(j) = Population(SelectIndex).chrom(j);
            end
        end
    end
    % Mutation
    for k = 1 : length(Population)
        for j = 1 : OPTIONS.numVar
            if OPTIONS.pmutate > rand
                TempPop(k).chrom(j) = OPTIONS.MinDomain(j) + (OPTIONS.MaxDomain(j) - OPTIONS.MinDomain(j)) .* rand;
            end
        end
    end
    % Replace the habitats with their new versions.
    Population = TempPop;
    % Make sure the population does not have duplicates. 
    if OPTIONS.clearDups
        Population = ClearDups(Population, OPTIONS);
    end
    % Calculate cost
    Population = OPTIONS.CostFunction(Population, OPTIONS);
    FnEvals = FnEvals + OPTIONS.popsize;
    % Calculate the opposite population if necessary, and replace the worst with the previous generation elites.
    if (OppositionType > 0) && (rand < JumpRate) && (NumOpps > 0)
        Population = PopSort(Population);
        OppositePop = GetOpposite(Population(OPTIONS.popsize-NumOpps+1 : end), OppositionType, OPTIONS);
        OppositePop = OPTIONS.CostFunction(OppositePop, OPTIONS);
        FnEvals = FnEvals + OPTIONS.popsize;
        Population = PopSort([Population, ElitePop, OppositePop]);
    else
        Population = PopSort([Population, ElitePop]);
    end
    Population = Population(1 : OPTIONS.popsize);
    % Display info to screen
    FnEvalArr(GenIndex+1) = FnEvals;
    [MinCost, AvgCost, MinConstrViol, AvgConstrViol] = ComputeCostAndConstrViol(Population, ...
        MinCost, AvgCost, MinConstrViol, AvgConstrViol, GenIndex, DisplayFlag);
    GenIndex = GenIndex + 1;
end
while FnEvalArr(end) > FnEvalMax
    FnEvalArr = FnEvalArr(1 : end-1);
end
MinCost = MinCost(1 : length(FnEvalArr));
AvgCost = AvgCost(1 : length(FnEvalArr));
Conclude(DisplayFlag, OPTIONS, Population, MinCost, AvgCost, MinConstrViol, AvgConstrViol);
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [OppositePop] = GetOpposite(Population, OppositionType, OPTIONS)
% Create an opposite population
% This assumes that each dimension has the same domain. This code needs to be modified for
% functions that have different domains for different dimensions.
Midpoint = (OPTIONS.MaxDomain + OPTIONS.MinDomain) / 2;
OppositePop = Population;
for i = 1 : length(Population)
    xo = 2 * Midpoint - Population(i).chrom;
    if OppositionType == 1
        % standard opposition
        OppositePop(i).chrom = xo;
    elseif OppositionType == 2
        %  quasi opposition
        OppositePop(i).chrom = Midpoint + (xo - Midpoint) .* rand(1, OPTIONS.numVar);
    elseif OppositionType == 3
        % super opposition
        for k = 1 : OPTIONS.numVar
            if xo(k) > Midpoint(k)
                OppositePop(i).chrom(k) = xo(k) + (OPTIONS.MaxDomain - xo(k)) * rand;
            else
                OppositePop(i).chrom(k) = OPTIONS.MinDomain(k) + (xo(k) - OPTIONS.MinDomain(k)) * rand;
            end
        end
    elseif OppositionType == 4
        % quasi reflected opposition
        OppositePop(i).chrom = Population(i).chrom + (Midpoint - Population(i).chrom) .* rand(1, OPTIONS.numVar);
    else
        disp('Unknown opposition type in function GetOpposite')
        break
    end
end
return