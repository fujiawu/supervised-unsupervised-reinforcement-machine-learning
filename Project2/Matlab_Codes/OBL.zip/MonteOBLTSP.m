function [MinCost] = MonteOBLTSP(Filename)
% Monte Carlo simulations to explore the effect of opposition-based learning on combinatorial optimization.
if ~exist('Filename', 'var')
    Filename = [];
end
nMonte = 40;
DisplayFlag = false;
JumpRateArr = [0.0 0.1 0.2 0.3 0.4];
JumpRatioArr = [0.1 0.2 0.3 0.4];
MinCost = zeros(length(JumpRateArr), length(JumpRatioArr), nMonte);
for i = 1 : nMonte
    disp(['Run # ', num2str(i), ' of ', num2str(nMonte)]);
    RandSeed = fix(sum(100*clock));
    for k = 1 : length(JumpRateArr)
        for m = 1 : length(JumpRatioArr)
            MinCostArr = OBLTSP(Filename, DisplayFlag, JumpRateArr(k), JumpRatioArr(m), RandSeed);
            MinCost(k, m, i) = MinCostArr(end);
        end
    end
end
StdDev = zeros(size(MinCost, 1), size(MinCost, 2));
for k = 1 : size(MinCost, 1)
    for m = 1 : size(MinCost, 2)
        StdDev(k, m) = std(MinCost(k, m, :));
    end
end
MinCost = mean(MinCost, 3);
display(MinCost)
display(StdDev)