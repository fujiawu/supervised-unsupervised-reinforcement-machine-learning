function [MinCost] = MonteOBBOJumpRate(ProblemFunction)
% Monte Carlo simulations to explore the effect of opposition-based learning on biogeography-based optimization.
if ~exist('ProblemFunction', 'var') || isempty(ProblemFunction)
    ProblemFunction = @Griewank;
end
nMonte = 20;
FnEvalMax = 2500;
DisplayFlag = false;
ShiftFlag = 2; % 0 means no shift, 1 means uniform shift, 2 means Gaussian shift of problem solution
JumpRateArr = [0 0.2];%[0.0 0.2 0.4 0.6 0.8 1.0];
OppRateArr = 1;%[0.2 0.4 0.6 0.8 1.0];
MinCost = zeros(length(JumpRateArr), 4, length(OppRateArr), nMonte);
for i = 1 : nMonte
    disp(['Run # ', num2str(i), ' of ', num2str(nMonte)]);
    RandSeed = fix(sum(100*clock));
    for OppType = 1 : 4
        for k = 1 : length(JumpRateArr)
            for m = 1 : length(OppRateArr)
                MinCostArr = OBBO(ProblemFunction, DisplayFlag, RandSeed, OppType, ...
                    JumpRateArr(k), FnEvalMax, OppRateArr(m), ShiftFlag);
                MinCost(k, OppType, m, i) = MinCostArr(end);
            end
        end
    end
end
MinCost = mean(MinCost, 4);
% first dimension corresponds to jump rates,
% second dimension correspond to opposition types, 
% third dimension corresponds to opposition rates
for m = 1 : length(OppRateArr)
    disp(['Opposition rate = ', num2str(OppRateArr(m))]);
    disp(MinCost(:,:,m))
end