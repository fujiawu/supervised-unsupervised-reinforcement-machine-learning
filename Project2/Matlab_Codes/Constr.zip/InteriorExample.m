function InteriorExample(delta, alpha)
% Reproduce Figure 19.1

if ~exist('delta', 'var') || isempty(delta)
    delta = 0.01;
end
if ~exist('alpha', 'var') || isempty(alpha)
    alpha = 1;
end

dx = 0.01;
x = -2 : dx : 3;
f = x.^2;

xprime = 1 : dx : 3;
penalty = (xprime - 1 + delta).^(-alpha);
fprime = xprime.^2 + penalty;

SetPlotOptions
plot(x,f,'r-', xprime,fprime,'b--'), hold on
xlabel('x')
text(-1, 1.8, 'f(x)')
text(1.5, 5, 'f''(x)')

xborder = [1 1];
axis([-2 3 0 10])
tempaxis = axis;
fborder = [tempaxis(3) tempaxis(4)];
plot(xborder, fborder, 'k:')