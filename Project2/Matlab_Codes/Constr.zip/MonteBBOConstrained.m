function [PctFeasibleRuns, MeanMin] = MonteBBOConstrained(nMonte)

% Monte Carlo execution of constrained evolutionary optimization software
% INPUTS:   nMonte = number of Monte Carlo simulations
% OUTPUTS:  NumFeasibleRuns is an array that contains the percent of Monte Carlo simulations that found
%               at least one feasible solution for each constraint method and each benchmark
%           MeanMin is an array that contains the cost of the best feasible solution found
%               for each constraint method and each benchmark, averaged over several Monte Carlo runs

if ~exist('nMonte', 'var') || isempty(nMonte)
    nMonte = 20; % number of Monte Carlo runs
end
% Benchmark functions - test only on the benchmarks without equality constraints
Bench = [ ...
    'c01'; ...
    'c07'; ...
    'c08'; ...
    'c13'; ...
    'c14'; ...
    'c15'];
NumConstrMethods = 9;
nBench = size(Bench, 1);
MeanMin = zeros(NumConstrMethods, nBench);
NumFeasibleRuns = zeros(NumConstrMethods, nBench);
DisplayFlag = false;
LinearFlag = true;
Blending = 0;
for k = 1 : nMonte
    RandSeed = fix(sum(100*clock));
    for j = 1 : nBench
        disp(['Monte Carlo simulation ', num2str(k), '/', num2str(nMonte), ', ', ...
            'Benchmark function ', num2str(j), '/', num2str(nBench)]);
        for ConstrMethod = 1 : NumConstrMethods
            [Cost] = eval(['BBO(@', Bench(j,:), ', ', num2str(DisplayFlag), ', ', num2str(LinearFlag), ', ', ...
                num2str(Blending), ', ', num2str(ConstrMethod), ', ', num2str(RandSeed), ');']);
            if ~isnan(Cost(end))
                NumFeasibleRuns(ConstrMethod, j) = NumFeasibleRuns(ConstrMethod, j) + 1;
                nf = NumFeasibleRuns(ConstrMethod, j);
                MeanMin(ConstrMethod, j) = ((nf - 1) * MeanMin(ConstrMethod, j) + Cost(end)) / nf;
            end
        end
    end
end
MeanMin(NumFeasibleRuns == 0) = nan;
PctFeasibleRuns = 100 * NumFeasibleRuns / nMonte;
