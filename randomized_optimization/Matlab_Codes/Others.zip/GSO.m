%
% EEC 693 Special Topics: Evolutionary Optimization Algorithms
% Group search optimizer (GSO) 
% Steve Szatmary
% 12/19/2012
%

function [MinCost] = GSO(ProblemFunction,DisplayFlag,a_max,theta_max,alpha_max,l_max,GenLimit)

% Group search optimizer for optimizing a general function.

% INPUTS: ProblemFunction: The handle of the function that returns 
%            the handles of the initialization and cost functions.
%         DisplayFlag: Determines whether or not to display information
%            during iterations and plot results.
%         a_max: A ranger tuning parameter that together with l_max 
%            determines how far a ranger can travel in one generation.
%         theta_max: The producer tuning parameter that defines how far the
%            the producer can turn its head.
%         alpha_max: A ranger tuning parameter that defines how far a
%            ranger can turn its head.
%         l_max: The producer tuning parameter that defines how far the
%            the producer can see and together with a_max determines how
%            far a ranger can travel in one generation.
%         GenLimit: The generation limit.
% OUTPUT: MinCost: An array of the best cost per generation

if ~exist('ProblemFunction', 'var') || isempty(ProblemFunction)
    ProblemFunction = @Ackley;
end
if ~exist('DisplayFlag', 'var') || isempty(DisplayFlag)
    DisplayFlag = true;
end
if ~exist('GenLimit', 'var') || isempty(GenLimit)
    GenLimit = 50;
end
OPTIONS.Maxgen = GenLimit;
OPTIONS.ShiftFlag = true;
[OPTIONS,MinCost,AvgCost,Population,MinConstrViol,AvgConstrViol] = ...
    Init(DisplayFlag,ProblemFunction,OPTIONS);
if ~exist('a_max', 'var') || isempty(a_max)
    a_max = round(sqrt(OPTIONS.numVar));
end
if ~exist('theta_max', 'var') || isempty(theta_max)
    theta_max = pi/(a_max^2);
end
if ~exist('alpha_max', 'var') || isempty(alpha_max)
    alpha_max = theta_max/2;
end
if ~exist('l_max', 'var') || isempty(l_max)
    l_max = norm(OPTIONS.MaxDomain - OPTIONS.MinDomain,2);
end

% Initialize headings.
for k = 1 : OPTIONS.popsize
    Population(k).phi(1:(OPTIONS.numVar-1)) = 2*pi*rand(1,(OPTIONS.numVar-1)); 
end

% Create storage for producer scanning.
x = struct('chrom',cell([1,4]),'cost',cell([1,4]),'phi',cell([1,4]));

% Begin the optimization loop.
for GenIndex = 1 : OPTIONS.Maxgen
    % Find the producer, scan and update.
    r_1 = randn;
    r_2 = rand;
    % Find x_p.
    x(1) = Population(1);
    % Find x_z.
    x(2).chrom = x(1).chrom + r_1*l_max*D(x(1).phi);
    x(2).chrom = max(min(x(2).chrom,OPTIONS.MaxDomain),OPTIONS.MinDomain);
    x(2).phi = x(1).phi; 
    % Find x_r.
    x(3).chrom = x(1).chrom + r_1*l_max*D(x(1).phi+r_2*theta_max/2);
    x(3).chrom = max(min(x(3).chrom,OPTIONS.MaxDomain),OPTIONS.MinDomain);
    x(3).phi = x(1).phi;
    % Find x_l.
    x(4).chrom = x(1).chrom + r_1*l_max*D(x(1).phi-r_2*theta_max/2);
    x(4).chrom = max(min(x(4).chrom,OPTIONS.MaxDomain),OPTIONS.MinDomain);
    x(4).phi = x(1).phi;
    % Compute the costs of the scanned locations and find the best one.
    x = OPTIONS.CostFunction(x,OPTIONS);
    x = PopSort(x);
    if x(1).cost < Population(1).cost
        Population(1) = x(1);
    else
        rho = 2*rand - 1;
        Population(1).phi = Population(1).phi + rho*alpha_max;
    end
    % Update the scroungers and rangers for this generation.
    for i = 2 : OPTIONS.popsize 
        r_2 = rand;
        if r_2 < 0.8
            r_3 = rand(1,OPTIONS.numVar);
            Population(i).chrom = Population(i).chrom + r_3.*(Population(1).chrom-Population(i).chrom);  
        else
            rho = 2*rand - 1;
            Population(i).phi = Population(i).phi + rho*alpha_max;
            r_1 = randn;
            Population(i).chrom = Population(i).chrom + a_max*l_max*r_1*D(Population(i).phi);
            Population(i).chrom = max(min(Population(i).chrom,OPTIONS.MaxDomain),OPTIONS.MinDomain);
        end
    end
    if OPTIONS.clearDups
        Population = ClearDups(Population,OPTIONS);
    end
    % Calculate cost
    Population = OPTIONS.CostFunction(Population,OPTIONS);
    % Sort from best to worst
    Population = PopSort(Population);
    [MinCost,AvgCost,MinConstrViol,AvgConstrViol] = ComputeCostAndConstrViol(Population,...
        MinCost,AvgCost,MinConstrViol,AvgConstrViol,GenIndex,DisplayFlag);
end
Conclude(DisplayFlag,OPTIONS,Population,MinCost,AvgCost,MinConstrViol,AvgConstrViol);
return
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% EEC 693 Special Topics: Evolutionary Optimization Algorithms
% GSO polar to rectangular coordinate system transformation
% Steve Szatmary
% 11/19/2012
function d = D(phi)
n = length(phi) + 1;
d = ones(1,n);
for q = 1:n-1
    d(1) = d(1)*cos(phi(q));
end
for j = 2:n-1
    d(j) = sin(phi(j-1));
    for q = j:n-1
        d(j) = d(j)*cos(phi(q));
    end    
end
d(n) = sin(phi(n-1));
return
end