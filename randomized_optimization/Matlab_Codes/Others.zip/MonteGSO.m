%
% EEC 693 Special Topics: Evolutionary Optimization Algorithms
% Monte Carlo simulation of group search optimizer (GSO)
% Steve Szatmary
% 11/19/2012
%

function MonteGSO 
Benchmarks = {'Ackley','Fletcher','Griewank','Penalty1','Penalty2',...
              'Quartic','Rastrigin','Rosenbrock','Schwefel12',...
              'Schwefel221','Schwefel222','Schwefel226','Sphere','Step'};
M = 50; % Number of Monte Carlo runs
N = 50; % Number of generations
n = length(Benchmarks);
AvgMinCost = zeros(n,N+1);
for i = 1:n
   fprintf('%s: Info: Starting benchmark %s runs...\n',mfilename,Benchmarks{i});
   for j = 1:M
      [MinCost] = GSO(str2func(Benchmarks{i}),false,[],[],[],[],N);
      AvgMinCost(i,:) = AvgMinCost(i,:) + MinCost'; 
   end
   fprintf('%s: Info: Benchmark %s done.\n',mfilename,Benchmarks{i});
end
AvgMinCost = AvgMinCost/M;
fprintf('\nGSO Results with Shifting:\n');
fprintf('Benchmark\t\tAverage Minimum Cost\n');
fprintf('---------\t\t--------------------\n');
for i = 1:n
   fprintf('%s\t\t%f\n',Benchmarks{i},AvgMinCost(i,N+1));
end
return
end