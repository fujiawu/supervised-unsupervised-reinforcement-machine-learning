function [MinDistance] = TSPMonte(Filename, nMonte)
% Use Monte Carlo simulations to explore the effects of various crossover methods,
% mutation methods, and initialization methods, on the traveling salesman problem.
if ~exist('Filename', 'var') || isempty(Filename)
    Filename = 'berlin52'; % Filename of TSP file
end
if ~exist('nMonte', 'var') || isempty(nMonte)
    nMonte = 20; % number of Monte Carlo simulations
end
Crossover = 1 : 5; % crossover methods
Mutation = 1 : 3; % mutation methods
InitParam = [0, 2, inf]; % initialization parameters
MinDistance = zeros(length(Crossover), length(Mutation), length(InitParam));
PopSize = 0;
MutationRate = 0.05;
MaxGen = 300;
for ndx = 1 : nMonte
    disp(['Monte Carlo simulation # ', num2str(ndx) ' / ', num2str(nMonte)])
    for c = 1 : length(Crossover)
        for m = 1 : length(Mutation)
            for i = 1 : length(InitParam)
                MinDist = TSP(Filename, false, PopSize, InitParam(i), Crossover(c), Mutation(m), MutationRate, MaxGen);
                MinDistance(c, m, i) = ((ndx - 1) * MinDistance(c, m, i) + MinDist(end)) / ndx;
            end
        end
    end
end