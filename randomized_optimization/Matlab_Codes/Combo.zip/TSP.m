function [MinDistance] = TSP(Filename, DisplayFlag, PopSize, InitParam, Crossover, MutationMethod, MutationRate, MaxGen)

% Traveling salesman problem optimization using evolutionary algorithms and the path representation.
% This is for the closed TSP, which means that we start and end at the same city.

% INPUTS: Filename is the name of the file that has the TSP data (no extension; .TSP assumed).
%            Assumed format of file is from http://comopt.ifi.uni-heidelberg.de/software/TSPLIB95.
%         DisplayFlag says whether or not to display information during iterations and plot results.
%         PopSize = population size (0 to set population size equal to one more than the number of cities)
%         InitParam = 0 (random initialization)
%                     n > 0 (initialize n individuals with the nearest neighbor algorithm; remaining initial tours are random)
%         Crossover = crossover method
%                     1: partially matched crossover (PMX)
%                     2: order crossover (OX)
%                     3: cycle crossover (CX)
%                     4: order based crossover (OBX)
%                     5: inver over crossover
%         MutationMethod = mutation method
%                          1: inversion
%                          2: insertion
%                          3: reciprocal exchange
%                          4: opposition
%         MutationRate = mutation rate = probability of mutating a child individual
%         MaxGen = number of generations
% OUTPUT: MinDistance = array of minimum distances obtained at each generation

if ~exist('Filename', 'var') || isempty(Filename)
    Filename = 'ulysses16';
end
if ~exist('DisplayFlag', 'var') || isempty(DisplayFlag)
    DisplayFlag = true;
end
if ~exist('PopSize', 'var') || isempty(PopSize)
    PopSize = 0; % This is redefined later in the program
end
if ~exist('InitParam', 'var') || isempty(InitParam)
    InitParam = 0;
end
if ~exist('Crossover', 'var') || isempty(Crossover)
    Crossover = 1;
end
if ~exist('MutationMethod', 'var') || isempty(MutationMethod)
    MutationMethod = 1;
end
if ~exist('MutationRate', 'var') || isempty(MutationRate)
    MutationRate = 0.05;
end
if ~exist('MaxGen', 'var') || isempty(MaxGen)
    MaxGen = 1000;
end
if DisplayFlag, disp('Initializing ...'), end

RandSeed = round(sum(100*clock));
if DisplayFlag
    disp(['Random seed = ', num2str(RandSeed)]);
end
RandSeed = RandStream.create('mt19937ar', 'seed', RandSeed);
RandStream.setGlobalStream(RandSeed);

% Read the input file and fill up the Coordinates array with the coordinates of each city
[Coord, EdgeWeightType] = GetCoordinates(Filename);
if isequal(EdgeWeightType, 'EUC_2D')
    % Do nothing
elseif isequal(EdgeWeightType, 'GEO')
    Coord = GetLongLat(Coord);
else
    disp('Edge Weight Type not recognized')
    return
end
DistanceArray = CreateDistanceArray(Coord, EdgeWeightType);

% Initialize the population and calculate the distance of each tour
NumCities = size(Coord, 1);
if PopSize == 0
    PopSize = NumCities + 1;
end
Population = struct('Tour', cell([1 PopSize]), 'Distance', cell([1 PopSize]));
Child = struct('Tour', cell([1 PopSize]), 'Distance', cell([1 PopSize]));
for i = 1 : min(InitParam, PopSize)
    % nearest neighbor initialization
    City = randi([1 NumCities]);
    Population(i).Tour(1) = City;
    Distances = DistanceArray(City, :);
    Distances(City) = inf;
    for k = 2 : NumCities
        [~, City] = min(Distances);
        Distances(City) = inf;
        Population(i).Tour(k) = City;
    end
end
for i = InitParam+1 : PopSize
    % random initialization
    Population(i).Tour = randperm(NumCities);
end
for i = 1 : PopSize
    % Make each tour a round trip that begins and ends at city #1
    ndx = find(Population(i).Tour == 1, 1, 'first');
    Population(i).Tour = circshift(Population(i).Tour, [0, 1-ndx]);
    Population(i).Tour(end+1) = Population(i).Tour(1);
    Population(i).Distance = CalcDistance(Population(i).Tour, DistanceArray);
end
[Population] = PopSortTSP(Population);

MinDistance = zeros(1, MaxGen);
AvgDistance = zeros(1, MaxGen);
MinDistance(1) = Population(1).Distance;
AvgDistance(1) = mean([Population.Distance]);
if DisplayFlag
    disp(['The best and mean of Generation # 0 are ', num2str(MinDistance(1)), ' and ', num2str(AvgDistance(1))]);
    % Plot the initial best tour
    SetPlotOptions
    PlotTour(Coord, Population(1).Tour), title('Best Tour at First Generation')
end

% Begin the optimization loop
SelectIndex = zeros(1, 2);
for GenIndex = 1 : MaxGen
    for k = 1 : 2 : PopSize % create child individuals
        % Roulette wheel selection
        Fitness = max([Population.Distance]) + min([Population.Distance]) - [Population.Distance];
        for i = 1 : 2
            RandomNum = rand * sum(Fitness);
            Select = Fitness(1);
            SelectIndex(i) = 1;
            while (RandomNum > Select) && (SelectIndex(i) < PopSize)
                SelectIndex(i) = SelectIndex(i) + 1;
                Select = Select + Fitness(SelectIndex(i));
            end
        end
        if Crossover == 1
            % Partially matched crossover
            CrossPoint = randi([2, NumCities]);
            Child(k).Tour = [Population(SelectIndex(1)).Tour(1:CrossPoint), Population(SelectIndex(2)).Tour(CrossPoint+1:end)];
            Child(k).Tour = MakeTourValid(Child(k).Tour);
            Child(k+1).Tour = [Population(SelectIndex(2)).Tour(1:CrossPoint), Population(SelectIndex(1)).Tour(CrossPoint+1:end)];
            Child(k+1).Tour = MakeTourValid(Child(k+1).Tour);
        elseif Crossover == 2
            % Order crossover
            for pindex = 1 : 2
                par1 = pindex; % Create the second child by reversing the roles of the two parents
                par2 = 3 - pindex;
                cindex = k + pindex - 1;
                StartNdx = randi([2, NumCities-1]);
                EndNdx = randi([StartNdx+1, NumCities]);
                Child(cindex).Tour = zeros(1, NumCities+1);
                Child(cindex).Tour(1) = 1;
                Child(cindex).Tour(end) = 1;
                Child(cindex).Tour(StartNdx : EndNdx) = Population(SelectIndex(par1)).Tour(StartNdx : EndNdx);
                for i = 2 : NumCities+1
                    City = Population(SelectIndex(par2)).Tour(i);
                    if isempty(find(Child(cindex).Tour == City, 1, 'first'))
                        FirstOpenSlot = find(Child(cindex).Tour == 0, 1, 'first');
                        Child(cindex).Tour(FirstOpenSlot) = City;
                    end
                end
            end
        elseif Crossover == 3
            % Cycle crossover
            for pindex = 1 : 2
                par1 = pindex; % Create the second child by reversing the roles of the two parents
                par2 = 3 - pindex;
                cindex = k + pindex - 1;
                Child(cindex).Tour = ones(1, NumCities+1);
                ndx = randi([2, NumCities]);
                City = Population(SelectIndex(par1)).Tour(ndx);
                while true
                    Child(cindex).Tour(ndx) = City;
                    City = Population(SelectIndex(par2)).Tour(ndx);
                    if ~isempty(find(Child(cindex).Tour == City, 1, 'first')), break, end
                    ndx = find(Population(SelectIndex(par1)).Tour == City, 1, 'first');
                end
                for i = 2 : NumCities
                    if Child(cindex).Tour(i) == 1
                        Child(cindex).Tour(i) = Population(SelectIndex(par2)).Tour(i);
                    end
                end
            end
        elseif Crossover == 4
            % order based crossover
            for pindex = 1 : 2
                par1 = pindex; % Create the second child by reversing the roles of the two parents
                par2 = 3 - pindex;
                cindex = k + pindex - 1;
                RandIndices = 1 + randperm(NumCities-1, randi(NumCities-1)); % a vector of random indices
                P2Cities =  Population(SelectIndex(par2)).Tour(RandIndices);
                Child(cindex).Tour = ones(1, NumCities+1);
                for i = 2 : NumCities
                    P1City = Population(SelectIndex(par1)).Tour(i);
                    if isempty(find(P2Cities == P1City, 1, 'first'))
                        Child(cindex).Tour(i) = P1City;
                    end
                end
                for i = 2 : NumCities
                    if Child(cindex).Tour(i) == 1
                        Child(cindex).Tour(i) = P2Cities(1);
                        P2Cities = P2Cities(2 : end);
                    end
                end
            end
        elseif Crossover == 5
            % inver over crossover
            for pindex = 1 : 2
                par1 = pindex; % Create the second child by reversing the roles of the two parents
                par2 = 3 - pindex;
                cindex = k + pindex - 1; % cindex = k the first time through, k+1 the second time through
                ndx1 = 1 + randi(NumCities-1);
                City1 = Population(SelectIndex(par1)).Tour(ndx1);
                ndx2 = 1 + find(Population(SelectIndex(par2)).Tour == City1, 1, 'first');
                if ndx2 > NumCities
                    ndx2 = ndx2 - 2;
                end
                City2 = Population(SelectIndex(par2)).Tour(ndx2);
                ndx2 = find(Population(SelectIndex(par1)).Tour == City2, 1, 'first');
                if ndx1 > ndx2
                    temp = ndx1;
                    ndx1 = ndx2;
                    ndx2 = temp;
                end
                Child(cindex).Tour = Population(SelectIndex(par1)).Tour;
                Child(cindex).Tour(ndx1:ndx2) = Child(cindex).Tour(ndx2:-1:ndx1);
            end
        end
        % Mutation
        for i = k : k+1
            if rand < MutationRate
                Child(i).Tour = MutateTSP(Child(i).Tour, MutationMethod);
            end
            Child(i).Distance = CalcDistance(Child(i).Tour, DistanceArray);
        end
    end
    Population = ReplaceDupsTSP([Population, Child], MutationMethod, DistanceArray);
    Population = PopSortTSP(Population);
    Population = Population(1 : PopSize);
    MinDistance(GenIndex+1) = Population(1).Distance;
    AvgDistance(GenIndex+1) = mean([Population.Distance]);
    if DisplayFlag
        disp(['The best and mean of Generation # ', num2str(GenIndex), ' are ', ...
            num2str(MinDistance(GenIndex+1)), ' and ', num2str(AvgDistance(GenIndex+1))]);
    end
end
if DisplayFlag
    ConcludeTSP(Population, MinDistance, AvgDistance, Coord);
    PlotBestTour(Filename, Coord, DistanceArray);
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Tour] = MakeTourValid(Tour)
% Repair an invalid tour that has duplicate cities.
% Assume that tour is closed, and that the first and last cities are correct.
NumCities = length(Tour) - 1;
DupCities = []; % array of duplicate cities, one element for each city that needs to be replaced
MissingCities = []; % array of missing cities, one element for each city that needs to be added
for i = 2 : NumCities
    indices = find(Tour == i);
    if length(indices) > 1
        DupCities = [DupCities, i*ones(1,length(indices)-1)]; %#ok<AGROW>
    elseif isempty(indices)
        MissingCities = [MissingCities, i]; %#ok<AGROW>
    end
end
for i = 1 : length(DupCities)
    DupIndex = find(Tour == DupCities(i), 1, 'first');
    Tour(DupIndex) = MissingCities(i);
end
return