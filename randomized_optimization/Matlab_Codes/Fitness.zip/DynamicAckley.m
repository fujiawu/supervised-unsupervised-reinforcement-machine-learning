function [InitFunction, CostFunction, FeasibleFunction] = DynamicAckley
InitFunction = @Init;
CostFunction = @Cost;
FeasibleFunction = [];
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Population, OPTIONS] = Init(OPTIONS)
% Initialize the population
if ~isfield(OPTIONS, 'MinDomain')
    OPTIONS.MinDomain = -32 * ones(1, OPTIONS.numVar);
end
if ~isfield(OPTIONS, 'MaxDomain')
    OPTIONS.MaxDomain = +32 * ones(1, OPTIONS.numVar);
end
OPTIONS.ShiftFlag = 1;
OPTIONS.RotationFlag = 1;
OPTIONS.CompositionSize = 10;
OPTIONS.phiMin = 10;
OPTIONS.phiMax = 100;
OPTIONS.ChangeSeverity = 18;
if ~isfield(OPTIONS, 'ChangePeriod')
    OPTIONS.ChangePeriod = 100; % number of generations between dynamic cost function changes
end
if ~isfield(OPTIONS, 'BiasChangeType')
    OPTIONS.BiasChangeType = 1; % use rotation matrix to change bias
end
OPTIONS.lambda = (OPTIONS.MaxDomain(1) - OPTIONS.MinDomain(1)) / 64;

OPTIONS.CompositionSize = 1;
OPTIONS.phiMin = 0;
OPTIONS.phiMax = 0;
OPTIONS.lambda = 1;

OPTIONS.TimeVarying = OPTIONS.phiMin + (OPTIONS.phiMax - OPTIONS.phiMin) * rand(1, OPTIONS.CompositionSize);
ShiftAmt = zeros(OPTIONS.CompositionSize, OPTIONS.numVar);
for i = 1 : OPTIONS.CompositionSize
    OPTIONS = ComputeRandomShift(OPTIONS);
    ShiftAmt(i, :) = OPTIONS.ShiftAmount;
    OPTIONS.RotationMatrix{i} = createRotMatrix(OPTIONS.numVar);
    OPTIONS.MaxCost(i) = AckleyCost(32 * ones(1, OPTIONS.numVar) * OPTIONS.RotationMatrix{i});
end
OPTIONS.ShiftAmount = ShiftAmt;

OPTIONS.MaxCost = 2000 * ones(OPTIONS.CompositionSize, 1);

Population = struct('chrom', cell([1 OPTIONS.popsize]), 'cost', cell([1 OPTIONS.popsize]));
for popindex = 1 : OPTIONS.popsize
    chrom = OPTIONS.MinDomain + (OPTIONS.MaxDomain - OPTIONS.MinDomain) .* rand(1,OPTIONS.numVar);
    Population(popindex).chrom = chrom;
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Population, OPTIONS] = Cost(Population, OPTIONS, Generation)
% Compute the cost of each member in Population
if exist('Generation', 'var') && (mod(Generation, OPTIONS.ChangePeriod) == 0) && (Generation < OPTIONS.Maxgen)
    r = 2 * rand(1, OPTIONS.CompositionSize) - 1;
    OPTIONS.TimeVarying = OPTIONS.TimeVarying + OPTIONS.ChangeSeverity * r; % small dynamics
    %OPTIONS.TimeVarying = OPTIONS.TimeVarying + 450 * (0.04 * sign(r) + 0.06 * r); % large dynamics
    OPTIONS.TimeVarying = max(min(OPTIONS.TimeVarying,  OPTIONS.phiMax), OPTIONS.phiMin);
    for m = 1 : OPTIONS.CompositionSize
        if OPTIONS.BiasChangeType == 1
            % Use rotation matrix to shift the bias
            OPTIONS.ShiftAmount(m, :) = OPTIONS.ShiftAmount(m, :) * OPTIONS.RotationMatrix{m};
        elseif OPTIONS.BiasChangeType == 2
            % Shift the bias by 10 percent of the search space size (one standard deviation)
            OPTIONS.ShiftAmount(m, :) = OPTIONS.ShiftAmount(m, :) + 0.1 * (OPTIONS.MaxDomain - OPTIONS.MinDomain) .* randn(1, OPTIONS.numVar);
            OPTIONS.ShiftAmount(m, :) = max(min(OPTIONS.ShiftAmount(m, :),  OPTIONS.MaxDomain), OPTIONS.MinDomain);
            
            % New random bias
%             ShiftAmt = zeros(OPTIONS.CompositionSize, OPTIONS.numVar);
%             for i = 1 : OPTIONS.CompositionSize
%                 OPTIONS = ComputeRandomShift(OPTIONS);
%                 ShiftAmt(i, :) = OPTIONS.ShiftAmount;
%             end
%             OPTIONS.ShiftAmount = ShiftAmt;
            
        end
    end
end
for popindex = 1 : length(Population)
    Population(popindex).cost = 0;
    weight = zeros(1, OPTIONS.CompositionSize);
    for m = 1 : OPTIONS.CompositionSize
        Chrom = Population(popindex).chrom - OPTIONS.ShiftAmount(m, :);
        weight(m) = exp( -sqrt( sum(Chrom.^2) / 2 / length(Chrom) ) );
    end
    weightMax = max(weight);
    weightFactor = 1 - weightMax^10;
    for m = 1 : OPTIONS.CompositionSize
        if abs(weight(m) - weightMax) > eps
            weight(m) = weight(m) * weightFactor;
        end
    end
    weight = weight / sum(weight);
    for m = 1 : OPTIONS.CompositionSize
        Chrom = (Population(popindex).chrom - OPTIONS.ShiftAmount(m, :)) / OPTIONS.lambda * OPTIONS.RotationMatrix{m};
        Subcost = AckleyCost(Chrom) * 2000 / OPTIONS.MaxCost(m) + OPTIONS.TimeVarying(m);
        Population(popindex).cost = Population(popindex).cost + weight(m) * Subcost;
    end
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Cost] = AckleyCost(Chrom)
% Compute the cost of each member in Population
p = length(Chrom);
sum1 = 0;
sum2 = 0;
for i = 1 : p
    sum1 = sum1 + Chrom(i)^2;
    sum2 = sum2 + cos(2*pi*Chrom(i));
end
Cost = 20 + exp(1) - 20 * exp(-0.2*sqrt(sum1/p)) - exp(sum2/p);
return