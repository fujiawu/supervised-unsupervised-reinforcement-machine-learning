function Overfitting

x = [0 1 2 3 4];
y = [1 3 2 5 4];
SetPlotOptions
figure, box on, hold on

xcont = min(x) : (max(x)-min(x))/100 : max(x);

p = polyfit(x, y, 1);
plot(xcont, polyval(p, xcont), 'r-')

p = polyfit(x, y, 2);
plot(xcont, polyval(p, xcont), 'b--')

p = polyfit(x, y, 4);
plot(xcont, polyval(p, xcont), 'k:')

plot(x, y, 'o')

legend('linear', 'quadratic', 'quartic', 'data points')