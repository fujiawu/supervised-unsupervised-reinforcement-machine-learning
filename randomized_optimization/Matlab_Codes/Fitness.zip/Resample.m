function Resample
SetPlotOptions
mu1 = 0;
mu2 = 0;
sigma1 = 1;
sigma2 = 1/2;
x = -4 : .05 : 4;
f1 = exp(-(x-mu1).^2 / 2 / sigma1^2) / sigma1 / sqrt(2 * pi);
f2 = exp(-(x-mu2).^2 / 2 / sigma2^2) / sigma2 / sqrt(2 * pi);
close all
plot(x, f1, 'r-', x, f2, 'b--')
xlabel('fitness')
ylabel('PDF')
