function [MinCost] = BBODynamic(ProblemFunction, DisplayFlag, LinearFlag, Blending, RandSeed, OPTIONS)

% Biogeography-based optimization (BBO) software for minimizing a time-varying function

% INPUTS: ProblemFunction = the handle of the function that returns
%                           the handles of the initialization and cost functions.
%         DisplayFlag = true or false, whether or not to display and plot results.
%         LinearFlag = true to use linear migration models, false to use sinusoidal migration models
%         Blending = migration blend parameter, between 0 and 1; 0 means standard BBO
%         RandSeed = random number seed
%         DynamicFlag = flag indicating whether or not the problem function is dynamic
%         OPTIONS = BBO options structure
%                   OPTIONS.Rtotal and OPTIONS.BiasChangeType are of special interest
%                   Rtotal > 0 indicates direct immigrant scheme after detection of dynamic change in cost function
%                   Rtotal = 0 indicates no adaptation due to dynamic change in cost function
%                   Rtotal = -1 indicates random re-initialization of population after detection of change
%                   BiasChangeType = 1 for rotation of bias
%                   BiasChangeType = 2 for moderate 10% change of bias (one standard deviation)
% OUTPUT: MinCost = array of best solution, one element for each generation

if ~exist('ProblemFunction', 'var') || isempty(ProblemFunction)
    ProblemFunction = @DynamicAckley;
end
if ~exist('DisplayFlag', 'var') || isempty(DisplayFlag)
    DisplayFlag = true;
end
if ~exist('LinearFlag', 'var') || isempty(LinearFlag)
    LinearFlag = true;
end
if ~exist('Blending', 'var') || isempty(Blending)
    Blending = 0;
end
if ~exist('RandSeed', 'var') || isempty(RandSeed)
    RandSeed = [];
end
if ~exist('OPTIONS', 'var') || isempty(OPTIONS) || ~isfield(OPTIONS, 'ChangePeriod')
    OPTIONS.ChangePeriod = 100; % number of generations between dynamic cost function changes
end
if ~isfield(OPTIONS, 'popsize')
    OPTIONS.popsize = 50; % total population size
end
if ~isfield(OPTIONS, 'Maxgen')
    OPTIONS.Maxgen = 400; % generation count limit
end
if ~isfield(OPTIONS, 'Rtotal')
    OPTIONS.Rtotal = 0.3; % proportion of population to replace when a dynamic change is detected in the cost function
end
OPTIONS.Rrandom = OPTIONS.Rtotal / 3; % proportion of population to replace with random individuals
OPTIONS.Relite = OPTIONS.Rtotal / 3; % proportion of population to replace with elite-based individuals
OPTIONS.Rdual = OPTIONS.Rtotal / 3; % proportion of population to replace with dual individuals
if ~isfield(OPTIONS, 'BiasChangeType')
    OPTIONS.BiasChangeType = 2; % moderate 10% change in bias offset
end

% Initialization
[OPTIONS, MinCost, AvgCost, Population, MinConstrViol, AvgConstrViol] = ...
    Init(DisplayFlag, ProblemFunction, OPTIONS, RandSeed);

% Compute immigration rate and emigration rate for each individual.
% lambda(i) is the immigration rate for habitat i.
% mu(i) is the emigration rate for habitat i.
[lambda, mu] = GetLambdaMu(length(Population), LinearFlag);

% Begin the optimization loop
for GenIndex = 1 : OPTIONS.Maxgen
    % Save the best habitats in a temporary array.
    ElitePop = Population(1 : OPTIONS.Keep);
    % Begin the migration loop
    TempPop = Population;
    for k = 1 : length(Population)
        % Probabilistically input new information into habitat i
        for j = 1 : OPTIONS.numVar
            if rand < lambda(k)
                % Pick a habitat from which to obtain a feature
                RandomNum = rand * sum(mu);
                Select = mu(1);
                SelectIndex = 1;
                while (RandomNum > Select) && (SelectIndex < OPTIONS.popsize)
                    SelectIndex = SelectIndex + 1;
                    Select = Select + mu(SelectIndex);
                end
                TempPop(k).chrom(j) = ...
                    Blending * Population(k).chrom(j) + (1 - Blending) * Population(SelectIndex).chrom(j);
            end
        end
    end
    % Mutation
    for k = 1 : length(Population)
        for j = 1 : OPTIONS.numVar
            if OPTIONS.pmutate > rand
                TempPop(k).chrom(j) = OPTIONS.MinDomain(j) + (OPTIONS.MaxDomain(j) - OPTIONS.MinDomain(j)) * rand;
            end
        end
    end
    % Replace the habitats with their new versions
    Population = TempPop;
    % Make sure the population does not have duplicates
    if OPTIONS.clearDups
        Population = ClearDups(Population, OPTIONS);
    end
    % Calculate cost. Note that we need to recalculate the cost of the elites because the cost function may have changed.
    [Population, OPTIONS] = OPTIONS.CostFunction([Population, ElitePop], OPTIONS, GenIndex);
    Population = PopSort(Population);
    Population = Population(1 : OPTIONS.popsize);
    [MinCost, AvgCost] = ComputeCostAndConstrViol(Population, MinCost, AvgCost, MinConstrViol, AvgConstrViol, GenIndex, DisplayFlag);
    % Adapt to a dynamic change in the cost function if needed
    if (MinCost(GenIndex+1) > MinCost(GenIndex)) && (OPTIONS.Rtotal ~= 0)
        if OPTIONS.Rtotal == -1
            % Restart with random population
            for popindex = 1 : OPTIONS.popsize
                chrom = OPTIONS.MinDomain + (OPTIONS.MaxDomain - OPTIONS.MinDomain) .* rand(1, OPTIONS.numVar);
                Population(popindex).chrom = chrom;
            end
            Population = OPTIONS.CostFunction(Population, OPTIONS);
            Population = PopSort(Population);
        else 
            % Direct immigrant scheme
            RandPop = struct('chrom', 'cost');
            for i = 1 : round(OPTIONS.Rrandom * OPTIONS.popsize)
                RandPop(i).chrom = OPTIONS.MinDomain + (OPTIONS.MaxDomain - OPTIONS.MinDomain) .* rand(1, OPTIONS.numVar);
            end
            ElitePop = struct('chrom', 'cost');
            for i = 1 : round(OPTIONS.Relite * OPTIONS.popsize)
                ElitePop(i).chrom = Population(i).chrom + 0.01 * (OPTIONS.MaxDomain - OPTIONS.MinDomain) .* randn(1, OPTIONS.numVar);
            end
            DualPop = struct('chrom', 'cost');
            for i = 1 : round(OPTIONS.Rdual * OPTIONS.popsize)
                DualPop(i).chrom = OPTIONS.MaxDomain + OPTIONS.MinDomain - Population(i).chrom;
            end
            TempPop = OPTIONS.CostFunction([RandPop, ElitePop, DualPop], OPTIONS);
            Population = PopSort([Population, TempPop]);
            Population = Population(1 : OPTIONS.popsize);
        end
    end
end
Conclude(DisplayFlag, OPTIONS, Population, MinCost, AvgCost, MinConstrViol, AvgConstrViol);
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [lambda, mu] = GetLambdaMu(N, Linear)
% Compute immigration rate and extinction rate for each species count.
% lambda(i) is the immigration rate for individual i.
% mu(i) is the emigration rate for individual i.
% This routine assumes the population is sorted from most fit to least fit.
iArray = 1 : N;
if Linear
    mu = (N - iArray) / N; % linear migration curves
else
    mu = (1 + cos(iArray*pi/N)) / 2; % sinusoidal migration curves
end
lambda = 1 - mu;
return