function BBODynamicMonte2
nMonte = 20;
OPTIONS.Maxgen = 400;
FnPtr = @DynamicAckley;
Display = false;
Linear = true;
Blending = 0;
Biases = [1 2]; % rotational change = 1, moderate 10% change = 2
Rtotals = [-1 0 0.3]; % random restart = -1, no restart = 0, 30% replacement = 0.3
MinCostArr = zeros(length(Biases), length(Rtotals), OPTIONS.Maxgen+1, nMonte);
for i = 1 : nMonte
    disp(['Run #', num2str(i), ' of ', num2str(nMonte)])
    RandSeed = fix(sum(100*clock));
    for b = 1 : length(Biases)
        OPTIONS.BiasChangeType = Biases(b);
        for r = 1 : length(Rtotals)
            OPTIONS.Rtotal = Rtotals(r);
            MinCost = BBODynamic(FnPtr, Display, Linear, Blending, RandSeed, OPTIONS);
            MinCostArr(b,r,:,i) = MinCost; 
        end
    end
end
close all
MinCostArr = mean(MinCostArr, 4);
figure, hold on
Gen = 0 : OPTIONS.Maxgen;
LegendStr = '';
Colors = ['r', 'b', 'g'; 'k', 'c', 'm'];
for b = 1 : length(Biases)
    for r = 1 : length(Rtotals)
        plot(Gen, squeeze(MinCostArr(b, r, :)), Colors(b, r));
        LegendStr = [LegendStr; 'Bias = ', num2str(b), ', Restart = ', num2str(r)]; %#ok<AGROW>
    end
end
xlabel('Generation')
ylabel('Cost')
legend(LegendStr)