function [InitFunction, CostFunction, FeasibleFunction] = DynamicSphere
InitFunction = @Init;
CostFunction = @Cost;
FeasibleFunction = [];
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Population, OPTIONS] = Init(OPTIONS)
% Initialize the population
if ~isfield(OPTIONS, 'MinDomain')
    OPTIONS.MinDomain = -5 * ones(1, OPTIONS.numVar);
end
if ~isfield(OPTIONS, 'MaxDomain')
    OPTIONS.MaxDomain = +5 * ones(1, OPTIONS.numVar);
end
OPTIONS.ShiftFlag = 1;
OPTIONS.RotationFlag = 1;
OPTIONS.CompositionSize = 10;
OPTIONS.phiMin = 10;
OPTIONS.phiMax = 100;
OPTIONS.ChangeSeverity = 18;
if ~isfield(OPTIONS, 'ChangePeriod')
    OPTIONS.ChangePeriod = 100; % number of generations between dynamic cost function changes
end
OPTIONS.lambda = (OPTIONS.MaxDomain - OPTIONS.MinDomain) / 200;
OPTIONS.TimeVarying = OPTIONS.phiMin + (OPTIONS.phiMax - OPTIONS.phiMin) * rand(1, OPTIONS.CompositionSize);
ShiftAmt = zeros(OPTIONS.CompositionSize, OPTIONS.numVar);
for i = 1 : OPTIONS.CompositionSize
    OPTIONS = ComputeRandomShift(OPTIONS);
    ShiftAmt(i, :) = OPTIONS.ShiftAmount;
    OPTIONS.RotationMatrix{i} = createRotMatrix(OPTIONS.numVar);
    OPTIONS.MaxCost(i) = SphereCost(100 * ones(1, OPTIONS.numVar) * OPTIONS.RotationMatrix{i});
end
OPTIONS.ShiftAmount = ShiftAmt;
Population = struct('chrom', cell([1 OPTIONS.popsize]), 'cost', cell([1 OPTIONS.popsize]));
for popindex = 1 : OPTIONS.popsize
    chrom = OPTIONS.MinDomain + (OPTIONS.MaxDomain - OPTIONS.MinDomain) .* rand(1,OPTIONS.numVar);
    Population(popindex).chrom = chrom;
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Population, OPTIONS] = Cost(Population, OPTIONS, Generation)
% Compute the cost of each member in Population
if exist('Generation', 'var') && (mod(Generation, OPTIONS.ChangePeriod) == 0) && (Generation < OPTIONS.Maxgen)
    r = 2 * rand(1, OPTIONS.CompositionSize) - 1;
    OPTIONS.TimeVarying = OPTIONS.TimeVarying + OPTIONS.ChangeSeverity * r;
    %OPTIONS.TimeVarying = OPTIONS.TimeVarying + 450 * (0.04 * sign(r) + 0.06 * r);
    OPTIONS.TimeVarying = max(min(OPTIONS.TimeVarying,  OPTIONS.phiMax), OPTIONS.phiMin);
    for m = 1 : OPTIONS.CompositionSize
        OPTIONS.ShiftAmount(m, :) = OPTIONS.ShiftAmount(m, :) * OPTIONS.RotationMatrix{m};
    end
end
for popindex = 1 : length(Population)
    Population(popindex).cost = 0;
    weight = zeros(1, OPTIONS.CompositionSize);
    for m = 1 : OPTIONS.CompositionSize
        Chrom = Population(popindex).chrom - OPTIONS.ShiftAmount(m, :);
        weight(m) = exp( -sqrt( sum(Chrom.^2) / 2 / length(Chrom) ) );
    end
    weightMax = max(weight);
    weightFactor = 1 - weightMax^10;
    for m = 1 : OPTIONS.CompositionSize
        if abs(weight(m) - weightMax) > eps
            weight(m) = weight(m) * weightFactor;
        end
    end
    weight = weight / sum(weight);
    for m = 1 : OPTIONS.CompositionSize
        Chrom = (Population(popindex).chrom - OPTIONS.ShiftAmount(m, :)) / OPTIONS.lambda(m) * OPTIONS.RotationMatrix{m};
        Subcost = SphereCost(Chrom) * 2000 / OPTIONS.MaxCost(m) + OPTIONS.TimeVarying(m);
        Population(popindex).cost = Population(popindex).cost + weight(m) * Subcost;
    end
end
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Cost] = SphereCost(Chrom)
% Compute the cost
Cost = sum(Chrom.^2);
return