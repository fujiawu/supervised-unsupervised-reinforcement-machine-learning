function DACE(FunctionIndex, LatinFlag)

% Design and Analysis of Computer Experiments
% Approximate the Branin or Goldstein-Price benchmark function in two dimensions
% Based on "Efficient global optimization of expensive black-box functions," by D. Jones, M. Schonlau, and W. Welch,
% Journal of Global Optimization, volume 13, number 4, pp. 455-492, 1998.
% NOTE: This routine uses "fmincon," which is part of Matlab's Optimization Toolbox.

% INPUTS:
% FunctionIndex = 1 (Branin) or 2 (Goldstein-Price)
% LatinFlag = true (use Latin hypercube sampling) or false (use uniform sampling)

global xSample ySample oneM

if ~exist('FunctionIndex', 'var')
    FunctionIndex = 1;
end
if ~exist('LatinFlag', 'var')
    LatinFlag = true;
end
close all
dim = 2; % problem dimension
% Calculate and plot the true function
if FunctionIndex == 1
    x1min = -5; x1max = 10; dx1 = 0.05;
    x2min = 0; x2max = 15; dx2 = 0.05;
else
    x1min = -2; x1max = 2; dx1 = 0.02;
    x2min = -2; x2max = 2; dx2 = 0.02;
end
Nx1 = floor((x1max - x1min) / dx1) + 1;
Nx2 = floor((x2max - x2min) / dx2) + 1;
objTrue = zeros(Nx1, Nx2);
i = 0;
for x1 = x1min : dx1 : x1max
    i = i + 1;
    k = 0;
    for x2 = x2min : dx2 : x2max
        k = k + 1;
        if FunctionIndex == 1
            objTrue(i, k) = Branin([x1 x2]);
        else
            objTrue(i, k) = GoldsteinPrice([x1 x2]);
        end
    end
end
x1 = x1min : dx1 : x1max;
x2 = x2min : dx2 : x2max;
figure, subplot(2,1,1), contour(x1, x2, objTrue, 40)
if FunctionIndex == 1
    title('Branin')
else
    title('Goldstein-Price')
end

% Pick some sample points
if LatinFlag
    % Latin hypercube sampling
    M = 21;
    x1Values = x1min : (x1max-x1min)/(M-1) : x1max+eps;
    x1Values = x1Values(randperm(M))';
    x2Values = x2min : (x2max-x2min)/(M-1) : x2max+eps;
    x2Values = x2Values(randperm(M))';
    xSample = [x1Values, x2Values];
    ySample = zeros(M, 1);
    for i = 1 : M
        if FunctionIndex == 1
            ySample(i) = Branin(xSample(i, :));
        else
            ySample(i) = log(GoldsteinPrice(xSample(i, :)));
        end
    end
else
    % Uniform sampling
    if FunctionIndex == 1
        dx1Sample = 3.5;
        dx2Sample = 3.5;
        xOffset = 1;
    else
        dx1Sample = 0.75;
        dx2Sample = 0.75;
        xOffset = 0;
    end
    M = ceil((x1max-x1min)/dx1Sample+eps) * ceil((x2max-x2min)/dx2Sample+eps);
    xSample = zeros(M, dim);
    ySample = zeros(M, 1);
    i = 0;
    for x1 = x1min+xOffset : dx1Sample : x1max+eps
        for x2 = x2min+xOffset : dx2Sample : x2max+eps
            i = i + 1;
            xSample(i, :) = [x1, x2];
            if FunctionIndex == 1
                ySample(i) = Branin([x1 x2]);
            else
                ySample(i) = log(GoldsteinPrice([x1 x2]));
            end
        end
    end
end

% Find theta and p to maximize Eq. 4 in Jones 1998
oneM = ones(M, 1);
x0 = [0.1 * ones(1, dim), 1.5 * ones(1, dim)];
LowerBound = [zeros(1, dim), ones(1, dim)];
UpperBound = [inf * ones(1, dim), 2 * ones(1, dim)];

% Note that the fmincon algorithm can have a significant effect on DACE performance
options = optimset('Algorithm', 'interior-point');
%options = optimset('Algorithm', 'sqp');
[x] = fmincon(@Likelihood, x0, [], [], [], [], LowerBound, UpperBound, [], options);
theta = x(1 : dim);
p = x(dim+1 : 2*dim);
disp(['theta = ', num2str(theta)])
disp(['p = ', num2str(p)])
R = zeros(M, M);
for i = 1 : M
    for j = 1 : M
        R(i, j) = sum(theta .* (abs(xSample(i, :) - xSample(j, :))).^p);
    end
end
R = exp(-R);
mu = (oneM' / R * ySample) / (oneM' / R * oneM);

% Calculate and plot the approximated function
r = zeros(M, 1);
obj = zeros(Nx1, Nx2);
i = 0;
for x1 = x1min : dx1 : x1max
    i = i + 1;
    k = 0;
    for x2 = x2min : dx2 : x2max
        k = k + 1;
        for j = 1 : M
            r(j) = sum(theta .* (abs([x1 x2] - xSample(j, :))).^p);
            r(j) = exp(-r(j));
        end
        obj(i, k) = mu + r' / R * (ySample - oneM * mu);
    end
end
if FunctionIndex == 2
    obj = exp(obj);
end
x1 = x1min : dx1 : x1max;
x2 = x2min : dx2 : x2max;
subplot(2,1,2), contour(x1, x2, obj, 40), title('DACE Approximation')

% Plot the sample points
hold on
for i = 1 : M
    plot(xSample(i,1), xSample(i,2), 'o');
end

RMSError = sqrt(sum(sum(objTrue - obj).^2) / Nx1 / Nx2);
disp(['RMS Approximation Error = ', num2str(RMSError)])

return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [z] = Branin(x)
z = (x(2) - (5 / (4 * pi^2)) * x(1)^2 + 5 * x(1) / pi - 6)^2 + 10 * (1 - 1 / (8 * pi)) * cos(x(1)) + 10;
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [z] = GoldsteinPrice(x)
a = 1 + (x(1) + x(2) + 1)^2 * (19 - 14 * x(1) + 3 * x(1)^2 - 14 * x(2) + 6 * x(1) * x(2) + 3 * x(2)^2);
b = 30 + (2 * x(1) - 3 * x(2))^2 * (18 - 32 * x(1) + 12 * x(1)^2 + 48 * x(2) - 36 * x(1) * x(2) + 27 * x(2)^2);
z = a * b;
return

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [f] = Likelihood(x)
global xSample ySample oneM
M = size(xSample, 1);
dim = size(xSample, 2);
theta = x(1 : dim);
p = x(dim+1 : 2*dim);
R = zeros(M, M);
for i = 1 : M
    for j = 1 : M
        R(i, j) = sum(theta .* (abs(xSample(i, :) - xSample(j, :))).^p);
    end
end
R = exp(-R);
mu = (oneM' / R * ySample) / (oneM' / R * oneM);
sigma2 = (ySample - oneM * mu)' / R * (ySample - oneM * mu) / M;
f = sigma2^(M/2) * sqrt(det(R));
f = f * 1e-20;
return