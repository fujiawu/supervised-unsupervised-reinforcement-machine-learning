function GaussianNoise
SetPlotOptions
mu1 = 0;
mu2 = 4;
sigma1 = 1;
sigma2 = 2;
x = -5 : .05 : 10;
f1 = exp(-(x-mu1).^2 / 2 / sigma1^2) / sigma1 / sqrt(2 * pi);
f2 = exp(-(x-mu2).^2 / 2 / sigma2^2) / sigma2 / sqrt(2 * pi);
close all
plot(x, f1, 'r-', x, f2, 'b--')
xlabel('f(x)')
ylabel('PDF(f(x))')
text(-3, 0.3, 'f(x_1)')
text(5, 0.2, 'f(x_2)')