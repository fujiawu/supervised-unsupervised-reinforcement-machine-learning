function BBODynamicMonte1
nMonte = 20;
FnPtr = @DynamicAckley;
DisplayFlag = false;
LinearFlag = true;
Blending = 0;
OPTIONS.BiasChangeType = 1; % rotational change in bias offset
MinCostStationary = [];
MinCostDynamic = [];
for i = 1 : nMonte
    disp(['Run #', num2str(i), ' of ', num2str(nMonte)])
    RandSeed = fix(sum(100*clock));
    OPTIONS.ChangePeriod = 0; % static cost function
    MinCostStationary = [MinCostStationary, BBODynamic(FnPtr, DisplayFlag, LinearFlag, Blending, RandSeed, OPTIONS)]; %#ok<AGROW>
    OPTIONS.ChangePeriod = 100; % dynamic cost function
    MinCostDynamic = [MinCostDynamic, BBODynamic(FnPtr, DisplayFlag, LinearFlag, Blending, RandSeed, OPTIONS)]; %#ok<AGROW>
end
close all
MinCostStationary = mean(MinCostStationary, 2);
MinCostDynamic = mean(MinCostDynamic, 2);
Gen = 0 : length(MinCostDynamic)-1;
plot(Gen,MinCostDynamic,'b-', Gen,MinCostStationary,'r--')
xlabel('Generation')
ylabel('Cost')
legend('Dynamic Cost Function', 'Stationary Cost Function')