function [Fragment] = AddNodes(Layers, GrowFlag, NumArgs, FirstPass)

% Recursively create a Lisp expression with a depth of Layers.
% This routine is initially called as AddNodes(Layers, GrowFlag).
% GrowFlag indicates whether the syntax tree is grown with the grow method (true) or the full method (false).

if Layers < 1
    error('Layers must be greater than 0')
end
if ~exist('FirstPass', 'var')
    NumArgs = 1;
    FirstPass = true;
end
TermSet = {'x', 'v', '-1'};
NumTerms = length(TermSet);
FnSet = struct('function', {'+', '-', '*', 'DIV', 'GT', 'abs'}, ...
                'numargs', {  2,   2,   2,     2,    2,    1});
NumFns = length(FnSet);
Fragment = [];
for i = 1 : NumArgs
    TermFlag = GrowFlag && (randi([1, NumFns+NumTerms]) > NumFns);
    if TermFlag || (Layers == 1)
        ndx = randi([1, NumTerms]);
        Fragment = [Fragment, ' ', TermSet{ndx}]; %#ok<AGROW>
    else
        ndx = randi([1, NumFns]);
        Fragment = strcat(Fragment, ' ( ', FnSet(ndx).function);
        NewFragment = AddNodes(Layers-1, GrowFlag, FnSet(ndx).numargs, false);
        Fragment = strcat(Fragment, NewFragment);
    end
end
if ~FirstPass
    Fragment = [Fragment, ') '];
end
return