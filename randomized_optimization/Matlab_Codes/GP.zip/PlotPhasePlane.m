function PlotPhasePlane(Filename)
% Plot the phase plane based on the files <Filename>.txt and <Filename>1.txt, which
% are created with the Lisp program PhasePlane.lisp.
% Note that the plots from this program won't make sense if the controls are not always saturated.

close all 
Controls = csvread([Filename, '.txt']);
figure, hold on
for i = 1 : size(Controls, 1)
    x = Controls(i, 1);
    v = Controls(i, 2);
    u = Controls(i, 3);
    if u < 0
        plot(x, v, 'r.');
    else
        plot(x, v, 'b.');
    end
end
xlabel('position')
ylabel('velocity')

figure, hold on
for i = 1 : size(Controls, 1)
    xold = x;
    uold = u;
    x = Controls(i, 1);
    v = Controls(i, 2);
    u = Controls(i, 3);
    if (x == xold) && (u ~= uold)
        plot(x, v, 'b.')
    end
end
xlabel('position')
ylabel('velocity')

% Plot the switching curve from the input file, along with the optimal switching curve
PhasePlane = csvread([Filename, '1.txt']);
figure, hold on
plot(PhasePlane(:, 1), PhasePlane(:, 2), 'b.')
xlabel('position')
ylabel('velocity')
axis([-1 1 -1 1]);
limits = axis;
v = limits(3) : 0.01 : limits(4);
x = -v .* abs(v) / 2;
plot(x, v, 'r--')
legend('GP Solution', 'Optimal Solution')
set(gca,'XTick',[-1 0 1])
set(gca,'YTick',[-1 0 1])
xlabel('Position')
ylabel('Velocity')
text(0.1, 0.5, 'u = -1')
text(-0.3, -0.5, 'u = +1')
grid
