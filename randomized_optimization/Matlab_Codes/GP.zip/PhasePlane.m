function PhasePlane

v = -2 : .01 : 2;
x = -v .* abs(v) / 2;
SetPlotOptions
close all
plot(x, v)
set(gca,'XTick',[-2 -1 0 1 2])
set(gca,'YTick',[-2 -1 0 1 2])
xlabel('Position')
ylabel('Velocity')
text(1, 1, 'u = -1', 'BackgroundColor', 'w')
text(-1, -1, 'u = +1', 'BackgroundColor', 'w')
grid

figure, hold on
plot(x, v, '--')
set(gca,'XTick',[-2 -1 0 1 2])
set(gca,'YTick',[-2 -1 0 1 2])
xlabel('Position')
ylabel('Velocity')
x = -0.5; % initial position
v = 1.5; % initial velocity
a = -1;
b = 2 * v;
c = x - v^2 / 2;
tswitch = (-b - sqrt(b^2-4*a*c)) / 2 / a;
dt = 0.001;
len = round(tswitch / dt) + 1;
varray = zeros(len, 1);
varray(1) = v;
xarray = zeros(len, 1);
xarray(1) = x;
i = 1;
for t = 0 : dt : tswitch
    i = i + 1;
    vold = v;
    v = v - dt;
    varray(i) = v;
    x = x + dt * (v + vold) / 2;
    xarray(i) = x;
end
while (abs(x) > 1e-3) || (abs(v) > 1e-3)
    i = i + 1;
    vold = v;
    v = v + dt;
    varray(i) = v;
    x = x + dt * (v + vold) / 2;
    xarray(i) = x;
end
plot(xarray, varray, 'r')
grid
legend('Switching Curve', 'Minimum Time Trajectory')
