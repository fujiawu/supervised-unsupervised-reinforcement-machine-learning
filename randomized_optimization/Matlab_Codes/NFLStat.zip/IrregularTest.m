function IrregularTest(DeceptiveFlag)

% DeceptiveFlag = false to use a random function, true to use deceptive function

if ~exist('DeceptiveFlag', 'var') || isempty(DeceptiveFlag)
    DeceptiveFlag = false;
end

[xArr, yArr] = Irregular(DeceptiveFlag);
[~, minIndex] = min(yArr);

Dim = length(xArr);
iterMax = 10000;

% Hill descending
NumGuessesArr = zeros(1, iterMax);
for iter = 1 : iterMax
    xguess = randi([1, Dim]);
    NumGuesses = 1;
    while true
        if xguess == minIndex, break, end
        yguess = yArr(xguess);
        if xguess > 1
            yleft = yArr(xguess - 1);
            NumGuesses = NumGuesses + 1;
        else
            yleft = inf;
        end
        if xguess < Dim
            yright = yArr(xguess + 1);
            NumGuesses = NumGuesses + 1;
        else
            yright = inf;
        end
        if (yguess < yleft) && (yguess < yright)
            xguess = randi([1, Dim]);
            NumGuesses = NumGuesses + 1;
        elseif yleft < yright
            xguess = xguess - 1;
        else
            xguess = xguess + 1;
        end
    end
    NumGuessesArr(iter) = NumGuesses;
end
disp(['Hill descending: average # guesses = ', num2str(mean(NumGuessesArr))]);

% Random search
NumGuessesArr = zeros(1, iterMax);
for iter = 1 : iterMax
    NumGuesses = 0;
    while true
        xguess = randi([1, Dim]);
        NumGuesses = NumGuesses + 1;
        if xguess == minIndex, break, end
    end
    NumGuessesArr(iter) = NumGuesses;
end
disp(['Random search: average # guesses = ', num2str(mean(NumGuessesArr))]);

% Hill ascending
NumGuessesArr = zeros(1, iterMax);
for iter = 1 : iterMax
    xguess = randi([1, Dim]);
    NumGuesses = 1;
    while true
        if xguess == minIndex, break, end
        yguess = yArr(xguess);
        if xguess > 1
            if (xguess - 1) == minIndex, break, end
            yleft = yArr(xguess - 1);
            NumGuesses = NumGuesses + 1;
        else
            yleft = -inf;
        end
        if xguess < Dim
            if (xguess + 1) == minIndex, break, end
            yright = yArr(xguess + 1);
            NumGuesses = NumGuesses + 1;
        else
            yright = -inf;
        end
        if (yguess > yleft) && (yguess > yright)
            xguess = randi([1, Dim]);
            NumGuesses = NumGuesses + 1;
        elseif yleft > yright
            xguess = xguess - 1;
        else
            xguess = xguess + 1;
        end
    end
    NumGuessesArr(iter) = NumGuesses;
end
disp(['Hill ascending: average # guesses = ', num2str(mean(NumGuessesArr))]);

