function [x, y] = Irregular(DeceptiveFlag)

% DeceptiveFlag = false to use a random function, true to use deceptive function

if ~exist('DeceptiveFlag', 'var') || isempty(DeceptiveFlag)
    DeceptiveFlag = false;
end
SetPlotOptions
if DeceptiveFlag
    x = 0 : 11;
    y(1:5) = 1 : 5;
    y(6) = 1/2;
    y(7:12) = 5 : -1 : 0;
else
    x = 0 : 10;
    y = rand(1, length(x));
end
y(end) = y(end-1);
stairs(x, y)
xlabel('x')
ylabel('f(x)')
set(gca, 'XTick', 0.5 : max(x))
xlabels = [];
for i = 1 : max(x)
    if i < 10
        xlabels = [xlabels; [' ', num2str(i, '%d')]];
    else
        xlabels = [xlabels; num2str(i, '%d')];
    end
end
temp = axis;
axis([min(x), max(x), temp(3:4)]);
set(gca, 'XTickLabel', xlabels)
x = x(1 : end-1);
y = y(1 : end-1);