A1 = [30.02, 29.99, 30.11, 29.97, 30.01, 29.99];
A2 = [29.89, 29.93, 29.72, 29.98, 30.02, 29.98];
N1 = length(A1);
N2 = length(A2);
A1bar = mean(A1);
A2bar = mean(A2);
sigma1 = std(A1);
sigma2 = std(A2);
S12 = sqrt(sigma1^2/N1+sigma2^2/N2);
df1 = S12^4 / ((sigma1^2/N1)^2/(N1-1)+(sigma2^2/N2)^2/(N2-1));
if N1 == N2
    df2 = (N1 - 1) * (sigma1^2 + sigma2^2)^2 / (sigma1^4 + sigma2^4);
end
t = abs(A1bar-A2bar) / S12;