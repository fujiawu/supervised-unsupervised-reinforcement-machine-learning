A = [4 5 3 2];
B = [6 4 4 5];
C = [5 7 6 6];
G = 3;
N = 4;
dfNum = G - 1;
dfDen = G * (N - 1);

% From "F Test Example" on YouTube
ABracket = ((sum(A))^2 + (sum(B))^2 + (sum(C))^2) / N;
YBracket = sum(A.^2) + sum(B.^2) + sum(C.^2);
TBracket = (sum(A) + sum(B) + sum(C))^2 / N / G;
SB = (ABracket - TBracket) / (G - 1);
SW = (YBracket - ABracket) / dfDen;
F1 = SB / SW;

% Another way
Abar = mean(A);
Bbar = mean(B);
Cbar = mean(C);
Tbar = mean([Abar, Bbar, Cbar]);
Avariance = (std(A))^2;
Bvariance = (std(B))^2;
Cvariance = (std(C))^2;
% Two equivalent expressions for SW
SW1 = mean([Avariance, Bvariance, Cvariance]);
SW2 = (sum((A - Abar).^2) + sum((B - Bbar).^2) + sum((C - Cbar).^2)) / dfDen;
SB = N * (sum((Tbar - Abar).^2) + sum((Tbar - Bbar).^2) + sum((Tbar - Cbar).^2)) / dfNum;
F2 = SB / SW1;