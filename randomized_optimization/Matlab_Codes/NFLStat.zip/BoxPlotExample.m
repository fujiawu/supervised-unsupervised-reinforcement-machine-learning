% Note: This script requires the Statistics Toolbox
close all;
h=boxplot([rand(20,1), rand(20,1)],'labels',{' ',' '});
set(h(1:6,:),'LineWidth',3);
set(gca,'fontsize',18);
text(0.7, -0.11, 'Algorithm C');
text(1.7, -0.11, 'Algorithm D');
set(findobj(gca,'Type','text'),'FontSize',18);